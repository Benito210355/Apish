#!/usr/bin/env python3
"""
CaféBot - Sistema de gestión de menú y pedidos para cafetería
Telegram Bot con roles, OCR de productos y animaciones ASCII
Autorizado para pruebas de seguridad - Cafetería interna
"""

import os
import re
import json
import sqlite3
import hashlib
import logging
import asyncio
from datetime import datetime
from functools import wraps
from typing import Dict, List, Optional, Tuple

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    filters, ContextTypes
)
from telegram.constants import ParseMode

try:
    import pytesseract
    from PIL import Image
    import cv2
    import numpy as np
    OCR_AVAILABLE = True
except ImportError:
    OCR_AVAILABLE = False
    print("[!] Instala: pip install pytesseract pillow opencv-python")
    print("    Y tesseract-ocr: sudo apt install tesseract-ocr")

# ─── Configuración ───────────────────────────────────────────────────────────
TOKEN = "8815662392:AAEXbjhB0IFCPL4WL1CKfWKw4jwy6ZjbN6A"
ADMIN_IDS = [8128659179]  # IDs de Telegram de los administradores
DB_PATH = "cafeteria.db"

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ─── Base de Datos ───────────────────────────────────────────────────────────

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            nombre TEXT,
            rol TEXT DEFAULT 'cliente',
            direccion TEXT,
            telefono TEXT,
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS categorias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT UNIQUE NOT NULL
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            precio REAL NOT NULL,
            categoria_id INTEGER,
            descripcion TEXT,
            disponible INTEGER DEFAULT 1,
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (categoria_id) REFERENCES categorias(id)
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS pedidos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            items TEXT NOT NULL,
            total REAL NOT NULL,
            estado TEXT DEFAULT 'pendiente',
            direccion TEXT,
            notas TEXT,
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES usuarios(user_id)
        )
    """)
    
    # Crear admin por defecto
    for uid in ADMIN_IDS:
        c.execute("""
            INSERT OR IGNORE INTO usuarios (user_id, nombre, rol)
            VALUES (?, 'Admin', 'admin')
        """, (uid,))
    
    conn.commit()
    conn.close()

# ─── Animaciones ASCII ───────────────────────────────────────────────────────

ANIMACIONES = {
    "cafe": """
    ╔══════════════════╗
    ║   ☕  CAFETERÍA  ║
    ║   (  )  (  )     ║
    ║    ||    ||      ║
    ╚══════════════════╝
    """,
    "bienvenida": """
    ╔══════════════════════════╗
    ║     🌟 BIENVENIDO 🌟    ║
    ║  SISTEMA DE PEDIDOS     ║
    ║     CAFETERÍA BOT       ║
    ╚══════════════════════════╝
    """,
    "pedido_recibido": """
    ╔══════════════════════════╗
    ║    ✅ PEDIDO RECIBIDO   ║
    ║  ╔═══╗ ╔═══╗ ╔═══╗    ║
    ║  ║ P ║ ║ E ║ ║ D ║    ║
    ║  ╚═══╝ ╚═══╝ ╚═══╝    ║
    ║  Preparando tu orden... ║
    ╚══════════════════════════╝
    """,
    "listo": """
    ╔══════════════════════════╗
    ║    🎉 PEDIDO LISTO 🎉   ║
    ║   ──╤╡ ─── ── ╞╤──    ║
    ║     │  DISFRUTA! │      ║
    ║   ──╧╡ ─── ── ╞╧──    ║
    ╚══════════════════════════╝
    """,
    "error": """
    ╔══════════════════════════╗
    ║    ❌ ERROR ❌          ║
    ║   ╱╲  ╱╲  ╱╲  ╱╲      ║
    ║  (xx) (xx) (xx) (xx)   ║
    ╚══════════════════════════╝
    """,
    "cargando": """
    ╔══════════════════════════╗
    ║   PROCESANDO...         ║
    ║   ████░░░░░░░░ 25%     ║
    ╚══════════════════════════╝
    """,
    "menu_ascii": """
    ╔══════════════════════════╗
    ║       📋 MENÚ 📋        ║
    ║  ┌──────────────────┐  ║
    ║  │ Selecciona abajo │  ║
    ║  └──────────────────┘  ║
    ╚══════════════════════════╝
    """
}

def animar(frame_name: str) -> str:
    """Devuelve la animación ASCII formateada"""
    return f"<pre>{ANIMACIONES.get(frame_name, '')}</pre>"

# ─── Decoradores de autorización ────────────────────────────────────────────

def solo_admin(func):
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT rol FROM usuarios WHERE user_id = ?", (user_id,))
        row = c.fetchone()
        conn.close()
        
        if not row or row[0] not in ('admin', 'superadmin'):
            await update.message.reply_text(
                f"{animar('error')}\n⛔ Acceso denegado. Solo administradores.",
                parse_mode=ParseMode.HTML
            )
            return
        return await func(update, context, *args, **kwargs)
    return wrapper

def solo_cliente(func):
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT rol FROM usuarios WHERE user_id = ?", (user_id,))
        row = c.fetchone()
        conn.close()
        
        if not row or row[0] not in ('cliente', 'admin', 'superadmin'):
            await update.message.reply_text(
                f"{animar('error')}\nRegístrate primero con /registro",
                parseMode=ParseMode.HTML
            )
            return
        return await func(update, context, *args, **kwargs)
    return wrapper

# ─── Procesamiento OCR de imágenes ──────────────────────────────────────────

def procesar_imagen_menu(image_path: str) -> List[Dict]:
    """
    Procesa una imagen del menú y extrae productos usando OCR
    Retorna lista de dicts: [{"nombre": "...", "precio": ...}, ...]
    """
    if not OCR_AVAILABLE:
        return []

    img = cv2.imread(image_path)
    if img is None:
        return []
    
    # Preprocesamiento para mejor OCR
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    
    # OCR con español
    config = '--psm 6 -l spa+eng'
    texto = pytesseract.image_to_string(thresh, config=config)
    
    productos = []
    lineas = texto.strip().split('\n')
    
    # Patrones comunes en menús: "Nombre $12.50" o "Nombre 12.50"
    patron_precio = re.compile(
        r'^[\s]*(.+?)\s+\$?([0-9]+[.,]?[0-9]*)\s*$', re.UNICODE
    )
    
    for linea in lineas:
        linea = linea.strip()
        if not linea or len(linea) < 3:
            continue
        
        match = patron_precio.match(linea)
        if match:
            nombre = match.group(1).strip().title()
            precio_str = match.group(2).replace(',', '.')
            try:
                precio = float(precio_str)
                if precio > 0 and precio < 9999:
                    productos.append({"nombre": nombre, "precio": precio})
            except ValueError:
                continue
    
    return productos

# ─── Handlers de Comandos ───────────────────────────────────────────────────

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /start - Inicio del bot"""
    user = update.effective_user
    
    # Registrar usuario si no existe
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT OR IGNORE INTO usuarios (user_id, username, nombre)
        VALUES (?, ?, ?)
    """, (user.id, user.username or "", user.first_name or ""))
    conn.commit()
    conn.close()
    
    await update.message.reply_text(
        f"{animar('bienvenida')}\n"
        f"☕ ¡Bienvenido {user.first_name} a Cafetería Bot!\n\n"
        f"Comandos disponibles:\n"
        f"📋 /menu - Ver el menú\n"
        f"🛒 /pedido - Hacer un pedido\n"
        f"📦 /mispedidos - Ver tus pedidos\n"
        f"👤 /perfil - Tu información\n"
        f"🔐 /admin - Panel admin (solo admins)",
        parse_mode=ParseMode.HTML
    )

async def registro(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /registro - Registrar/actualizar perfil"""
    user = update.effective_user
    args = context.args
    
    if len(args) < 1:
        await update.message.reply_text(
            "Uso: /registro <nombre> [dirección] [teléfono]\n"
            "Ej: /registro Juan Pérez \"Calle 123\" 555-1234"
        )
        return
    
    nombre = args[0]
    direccion = args[1] if len(args) > 1 else ""
    telefono = args[2] if len(args) > 2 else ""
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO usuarios (user_id, username, nombre, direccion, telefono)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            nombre = excluded.nombre,
            direccion = excluded.direccion,
            telefono = excluded.telefono
    """, (user.id, user.username or "", nombre, direccion, telefono))
    conn.commit()
    conn.close()
    
    await update.message.reply_text(
        f"✅ Registro completado:\n"
        f"👤 {nombre}\n"
        f"📍 {direccion}\n"
        f"📞 {telefono}"
    )

async def ver_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /menu - Mostrar menú con categorías"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Obtener categorías
    c.execute("SELECT id, nombre FROM categorias ORDER BY nombre")
    categorias = c.fetchall()
    
    mensaje = f"{animar('menu_ascii')}\n📋 **MENÚ COMPLETO**\n\n"
    
    if not categorias:
        c.execute("SELECT id, nombre, precio FROM productos WHERE disponible = 1")
        productos = c.fetchall()
        if productos:
            mensaje += "**TODOS LOS PRODUCTOS:**\n"
            for pid, nombre, precio in productos:
                mensaje += f"• {nombre} — ${precio:.2f}\n"
        else:
            mensaje += "📭 El menú está vacío. Los administradores pueden agregar productos con /agregar\n"
    else:
        for cat_id, cat_nombre in categorias:
            c.execute("""
                SELECT id, nombre, precio FROM productos 
                WHERE categoria_id = ? AND disponible = 1
                ORDER BY nombre
            """, (cat_id,))
            productos = c.fetchall()
            
            if productos:
                mensaje += f"**{cat_nombre.upper()}**\n"
                for pid, nombre, precio in productos:
                    mensaje += f"  • {nombre} — ${precio:.2f}\n"
                mensaje += "\n"
    
    conn.close()
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

async def hacer_pedido(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /pedido - Iniciar proceso de pedido"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("SELECT id, nombre, precio FROM productos WHERE disponible = 1 ORDER BY nombre")
    productos = c.fetchall()
    conn.close()
    
    if not productos:
        await update.message.reply_text(
            f"{animar('error')}\n📭 No hay productos disponibles. Contacta al administrador.",
            parse_mode=ParseMode.HTML
        )
        return
    
    # Crear teclado inline con productos
    keyboard = []
    for pid, nombre, precio in productos:
        keyboard.append([
            InlineKeyboardButton(
                f"{nombre} - ${precio:.2f}", callback_data=f"prod_{pid}"
            )
        ])
    
    keyboard.append([InlineKeyboardButton("✅ Finalizar pedido", callback_data="finalizar")])
    keyboard.append([InlineKeyboardButton("❌ Cancelar", callback_data="cancelar")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Inicializar carrito en context.user_data
    context.user_data['carrito'] = []
    
    await update.message.reply_text(
        f"{animar('pedido_recibido')}\n"
        f"🛒 Selecciona los productos que deseas:\n"
        f"(Toca cada producto para agregarlo al carrito)",
        reply_markup=reply_markup,
        parse_mode=ParseMode.HTML
    )

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manejar clicks en botones inline"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "cancelar":
        context.user_data['carrito'] = []
        await query.edit_message_text("❌ Pedido cancelado.")
        return
    
    if data == "finalizar":
        carrito = context.user_data.get('carrito', [])
        if not carrito:
            await query.edit_message_text("❌ Carrito vacío. Agrega productos primero.")
            return
        
        # Calcular total
        total = sum(item['precio'] for item in carrito)
        
        # Guardar pedido
        user_id = update.effective_user.id
        items_json = json.dumps(carrito, ensure_ascii=False)
        
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("""
            INSERT INTO pedidos (user_id, items, total, estado)
            VALUES (?, ?, ?, 'pendiente')
        """, (user_id, items_json, total))
        pedido_id = c.lastrowid
        conn.commit()
        conn.close()
        
        # Mostrar resumen
        resumen = f"{animar('listo')}\n"
        resumen += f"✅ **PEDIDO #{pedido_id} CONFIRMADO**\n\n"
        resumen += "**Tu pedido:**\n"
        for item in carrito:
            resumen += f"  • {item['nombre']} — ${item['precio']:.2f}\n"
        resumen += f"\n💰 **Total: ${total:.2f}**\n"
        resumen += "\n⏳ Espera a que el administrador confirme."
        
        await query.edit_message_text(resumen, parse_mode=ParseMode.MARKDOWN)
        
        # Notificar a admins
        for admin_id in ADMIN_IDS:
            try:
                await context.bot.send_message(
                    admin_id,
                    f"{animar('cargando')}\n"
                    f"📦 **NUEVO PEDIDO #{pedido_id}**\n"
                    f"👤 Usuario: {update.effective_user.first_name}\n"
                    f"💰 Total: ${total:.2f}\n"
                    f"Estado: ⏳ Pendiente\n\n"
                    f"/confirmar {pedido_id} - Confirmar pedido\n"
                    f"/preparar {pedido_id} - Marcar en preparación\n"
                    f"/listo {pedido_id} - Marcar como listo",
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error notificando admin {admin_id}: {e}")
        
        context.user_data['carrito'] = []
        return
    
    if data.startswith("prod_"):
        prod_id = int(data.split("_")[1])
        
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT nombre, precio FROM productos WHERE id = ?", (prod_id,))
        row = c.fetchone()
        conn.close()
        
        if row:
            nombre, precio = row
            if 'carrito' not in context.user_data:
                context.user_data['carrito'] = []
            
            context.user_data['carrito'].append({
                'id': prod_id,
                'nombre': nombre,
                'precio': precio
            })
            
            total_carrito = sum(item['precio'] for item in context.user_data['carrito'])
            
            await query.edit_message_text(
                f"✅ **{nombre}** agregado al carrito (${precio:.2f})\n"
                f"🛒 Total actual: **${total_carrito:.2f}**\n\n"
                f"Selecciona más productos o presiona 'Finalizar pedido'",
                reply_markup=query.message.reply_markup,
                parse_mode=ParseMode.MARKDOWN
            )

async def mis_pedidos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /mispedidos - Ver historial de pedidos"""
    user_id = update.effective_user.id
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT id, items, total, estado, creado_en 
        FROM pedidos WHERE user_id = ? 
        ORDER BY creado_en DESC LIMIT 10
    """, (user_id,))
    pedidos = c.fetchall()
    conn.close()
    
    if not pedidos:
        await update.message.reply_text("📭 No tienes pedidos aún. Usa /pedido para hacer uno.")
        return
    
    mensaje = f"{animar('cafe')}\n📋 **MIS PEDIDOS**\n\n"
    
    estados_emoji = {
        'pendiente': '⏳',
        'confirmado': '✅',
        'preparando': '👨‍🍳',
        'listo': '🎉',
        'entregado': '📦',
        'cancelado': '❌'
    }
    
    for pid, items_json, total, estado, fecha in pedidos:
        items = json.loads(items_json)
        items_str = ", ".join([f"{i['nombre']}" for i in items])
        emoji = estados_emoji.get(estado, '❓')
        
        mensaje += f"#{pid} {emoji} **{estado.upper()}**\n"
        mensaje += f"   {items_str}\n"
        mensaje += f"   💰 ${total:.2f} | {fecha[:16]}\n\n"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

async def perfil(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /perfil - Ver información del perfil"""
    user_id = update.effective_user.id
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM usuarios WHERE user_id = ?", (user_id,))
    row = c.fetchone()
    conn.close()
    
    if not row:
        await update.message.reply_text("Regístrate con /registro")
        return
    
    mensaje = f"{animar('cafe')}\n👤 **TU PERFIL**\n\n"
    mensaje += f"ID: `{row[0]}`\n"
    mensaje += f"👤 Nombre: {row[2]}\n"
    mensaje += f"🔐 Rol: {row[3]}\n"
    mensaje += f"📍 Dirección: {row[4] or 'No registrada'}\n"
    mensaje += f"📞 Teléfono: {row[5] or 'No registrado'}"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

# ─── Comandos de Administración ─────────────────────────────────────────────

@ solo_admin
async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /admin - Panel de administración"""
    await update.message.reply_text(
        f"{animar('bienvenida')}\n"
        f"🔐 **PANEL DE ADMINISTRACIÓN**\n\n"
        f"📸 /agregar - Agregar productos manualmente\n"
        f"🖼️ Envía una **foto del menú** para extraer productos automáticamente\n"
        f"📂 /categorias - Gestionar categorías\n"
        f"📋 /listaproductos - Ver todos los productos\n"
        f"❌ /eliminar <id> - Eliminar producto\n"
        f"🔄 /disponible <id> - Cambiar disponibilidad\n"
        f"📦 /pedidos - Ver pedidos pendientes\n"
        f"✅ /confirmar <id> - Confirmar pedido\n"
        f"👨‍🍳 /preparar <id> - Marcar en preparación\n"
        f"🎉 /listo <id> - Marcar como listo\n"
        f"👥 /usuarios - Listar usuarios registrados",
        parse_mode=ParseMode.MARKDOWN
    )

@ solo_admin
async def agregar_producto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /agregar - Agregar producto manualmente"""
    args = context.args
    
    if len(args) < 2:
        await update.message.reply_text(
            "Uso: /agregar <nombre> <precio> [categoría]\n"
            "Ej: /agregar \"Café Latte\" 3.50 Bebidas\n\n"
            "O envía una foto del menú para extraer productos automáticamente."
        )
        return
    
    nombre = args[0]
    try:
        precio = float(args[1].replace(',', '.'))
    except ValueError:
        await update.message.reply_text("❌ Precio inválido. Usa formato: 12.50")
        return
    
    categoria_nombre = args[2] if len(args) > 2 else "General"
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Obtener o crear categoría
    c.execute("SELECT id FROM categorias WHERE nombre = ?", (categoria_nombre,))
    cat_row = c.fetchone()
    if cat_row:
        cat_id = cat_row[0]
    else:
        c.execute("INSERT INTO categorias (nombre) VALUES (?)", (categoria_nombre,))
        cat_id = c.lastrowid
    
    c.execute("""
        INSERT INTO productos (nombre, precio, categoria_id)
        VALUES (?, ?, ?)
    """, (nombre, precio, cat_id))
    conn.commit()
    conn.close()
    
    await update.message.reply_text(
        f"✅ Producto agregado:\n"
        f"• {nombre} — ${precio:.2f}\n"
        f"• Categoría: {categoria_nombre}"
    )

@ solo_admin
async def listar_productos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /listaproductos - Listar todos los productos"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        SELECT p.id, p.nombre, p.precio, c.nombre, p.disponible 
        FROM productos p
        LEFT JOIN categorias c ON p.categoria_id = c.id
        ORDER BY c.nombre, p.nombre
    """)
    productos = c.fetchall()
    conn.close()
    
    if not productos:
        await update.message.reply_text("📭 No hay productos registrados.")
        return
    
    mensaje = "📋 **TODOS LOS PRODUCTOS**\n\n"
    for pid, nombre, precio, cat, disp in productos:
        estado = "✅" if disp else "❌"
        mensaje += f"{estado} `#{pid}` **{nombre}** — ${precio:.2f} [{cat}]\n"
    
    mensaje += "\nUsa /disponible <id> para cambiar disponibilidad"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

@ solo_admin
async def eliminar_producto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /eliminar - Eliminar un producto"""
    if not context.args:
        await update.message.reply_text("Uso: /eliminar <id_producto>")
        return
    
    try:
        prod_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID inválido")
        return
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("DELETE FROM productos WHERE id = ?", (prod_id,))
    if c.rowcount > 0:
        conn.commit()
        await update.message.reply_text(f"✅ Producto #{prod_id} eliminado.")
    else:
        await update.message.reply_text(f"❌ Producto #{prod_id} no encontrado.")
    conn.close()

@ solo_admin
async def cambiar_disponibilidad(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /disponible - Cambiar disponibilidad de producto"""
    if not context.args:
        await update.message.reply_text("Uso: /disponible <id_producto>")
        return
    
    try:
        prod_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID inválido")
        return
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT disponible FROM productos WHERE id = ?", (prod_id,))
    row = c.fetchone()
    
    if not row:
        await update.message.reply_text(f"❌ Producto #{prod_id} no encontrado.")
        conn.close()
        return
    
    nuevo = 0 if row[0] else 1
    c.execute("UPDATE productos SET disponible = ? WHERE id = ?", (nuevo, prod_id))
    conn.commit()
    conn.close()
    
    estado = "disponible" if nuevo else "no disponible"
    await update.message.reply_text(f"✅ Producto #{prod_id} ahora está **{estado}**.", parse_mode=ParseMode.MARKDOWN)

@ solo_admin
async def ver_pedidos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /pedidos - Ver pedidos pendientes"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        SELECT p.id, p.user_id, u.nombre, p.items, p.total, p.estado, p.creado_en
        FROM pedidos p
        JOIN usuarios u ON p.user_id = u.user_id
        WHERE p.estado IN ('pendiente', 'confirmado', 'preparando')
        ORDER BY p.creado_en ASC
    """)
    pedidos = c.fetchall()
    conn.close()
    
    if not pedidos:
        await update.message.reply_text("📭 No hay pedidos pendientes.")
        return
    
    mensaje = f"{animar('cargando')}\n📦 **PEDIDOS PENDIENTES**\n\n"
    
    estados_emoji = {
        'pendiente': '⏳',
        'confirmado': '✅',
        'preparando': '👨‍🍳',
    }
    
    for pid, uid, nombre, items_json, total, estado, fecha in pedidos[:5]:
        items = json.loads(items_json)
        items_str = "\n    ".join([f"• {i['nombre']} (${i['precio']:.2f})" for i in items])
        emoji = estados_emoji.get(estado, '❓')
        
        mensaje += f"#{pid} {emoji} **{estado.upper()}**\n"
        mensaje += f"   👤 {nombre}\n"
        mensaje += f"   {items_str}\n"
        mensaje += f"   💰 **${total:.2f}**\n\n"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

@ solo_admin
async def gestionar_pedido(update: Update, context: ContextTypes.DEFAULT_TYPE, nuevo_estado: str):
    """Función auxiliar para cambiar estado de pedido"""
    if not context.args:
        await update.message.reply_text(f"Uso: /{nuevo_estado} <id_pedido>")
        return
    
    try:
        pedido_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID inválido")
        return
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT user_id, items, total FROM pedidos WHERE id = ?", (pedido_id,))
    row = c.fetchone()
    
    if not row:
        await update.message.reply_text(f"❌ Pedido #{pedido_id} no encontrado.")
        conn.close()
        return
    
    user_id, items_json, total = row
    
    c.execute("UPDATE pedidos SET estado = ? WHERE id = ?", (nuevo_estado, pedido_id))
    conn.commit()
    conn.close()
    
    estados_msg = {
        'confirmado': '✅ Pedido confirmado',
        'preparando': '👨‍🍳 Pedido en preparación',
        'listo': '🎉 Pedido listo para recoger'
    }
    
    await update.message.reply_text(f"{estados_msg.get(nuevo_estado, '')} #{pedido_id}")
    
    # Notificar al usuario
    try:
        items = json.loads(items_json)
        items_str = "\n".join([f"• {i['nombre']}" for i in items])
        
        anim = 'listo' if nuevo_estado == 'listo' else 'cargando'
        
        await context.bot.send_message(
            user_id,
            f"{animar(anim)}\n"
            f"📦 **Pedido #{pedido_id}**\n"
            f"Estado: **{nuevo_estado.upper()}**\n\n"
            f"{items_str}\n\n💰 Total: ${total:.2f}",
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        logger.error(f"Error notificando usuario: {e}")

@ solo_admin
async def confirmar_pedido(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await gestionar_pedido(update, context, 'confirmado')

@ solo_admin
async def preparar_pedido(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await gestionar_pedido(update, context, 'preparando')

@ solo_admin
async def pedido_listo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await gestionar_pedido(update, context, 'listo')

@ solo_admin
async def listar_usuarios(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /usuarios - Listar usuarios registrados"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT user_id, nombre, rol, creado_en FROM usuarios ORDER BY creado_en DESC")
    usuarios = c.fetchall()
    conn.close()
    
    if not usuarios:
        await update.message.reply_text("No hay usuarios registrados.")
        return
    
    mensaje = "👥 **USUARIOS REGISTRADOS**\n\n"
    for uid, nombre, rol, fecha in usuarios:
        mensaje += f"`{uid}` | **{nombre}** | {rol}\n"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

# ─── Handler de Fotos (OCR) ─────────────────────────────────────────────────

async def foto_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Procesa fotos enviadas por admins para extraer productos del menú
    """
    user_id = update.effective_user.id
    
    # Verificar si es admin
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT rol FROM usuarios WHERE user_id = ?", (user_id,))
    row = c.fetchone()
    conn.close()
    
    if not row or row[0] not in ('admin', 'superadmin'):
        await update.message.reply_text(
            f"{animar('error')}\n⛔ Solo administradores pueden subir menús.",
            parse_mode=ParseMode.HTML
        )
        return
    
    if not OCR_AVAILABLE:
        await update.message.reply_text(
            "⚠️ OCR no disponible. Instala:\n"
            "`pip install pytesseract pillow opencv-python`\n"
            "`sudo apt install tesseract-ocr tesseract-ocr-spa`",
            parse_mode=ParseMode.MARKDOWN
        )
        return
    
    # Descargar foto
    photo_file = await update.message.photo[-1].get_file()
    photo_path = f"menu_{user_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
    await photo_file.download_to_drive(photo_path)
    
    msg = await update.message.reply_text(
        f"{animar('cargando')}\n🔍 Procesando imagen del menú...",
        parse_mode=ParseMode.HTML
    )
    
    # Extraer productos
    productos = procesar_imagen_menu(photo_path)
    
    if not productos:
        await msg.edit_text(
            f"{animar('error')}\n"
            "❌ No se pudieron extraer productos de la imagen.\n\n"
            "Sugerencias:\n"
            "• Asegúrate de que la foto sea clara y legible\n"
            "• Los precios deben tener formato: Nombre $12.50\n"
            "• Usa buena iluminación\n"
            "• También puedes usar /agregar manualmente",
            parse_mode=ParseMode.HTML
        )
        # Limpiar archivo
        try:
            os.remove(photo_path)
        except:
            pass
        return
    
    # Guardar productos en BD
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    agregados = 0
    for prod in productos:
        # Verificar si ya existe
        c.execute("SELECT id FROM productos WHERE nombre = ?", (prod['nombre'],))
        if not c.fetchone():
            c.execute("""
                INSERT INTO productos (nombre, precio)
                VALUES (?, ?)
            """, (prod['nombre'], prod['precio']))
            agregados += 1
    
    conn.commit()
    conn.close()
    
    # Mostrar resultados
    resumen = f"✅ **Procesamiento completado**\n\n"
    resumen += f"📸 Productos detectados: **{len(productos)}**\n"
    resumen += f"➕ Nuevos agregados: **{agregados}**\n"
    resumen += f"🔁 Ya existentes: **{len(productos) - agregados}**\n\n"
    
    if productos:
        resumen += "**Productos encontrados:**\n"
        for i, prod in enumerate(productos[:15], 1):
            resumen += f"{i}. {prod['nombre']} — ${prod['precio']:.2f}\n"
        if len(productos) > 15:
            resumen += f"... y {len(productos) - 15} más\n"
    
    resumen += "\n📋 Usa /menu para ver el menú completo"
    
    await msg.edit_text(resumen, parse_mode=ParseMode.MARKDOWN)
    
    # Limpiar archivo
    try:
        os.remove(photo_path)
    except:
        pass

# ─── Main ────────────────────────────────────────────────────────────────────

def main():
    """Inicializar y ejecutar el bot"""
    # Inicializar BD
    init_db()
    
    # Crear aplicación
    app = Application.builder().token(TOKEN).build()
    
    # Handlers de comandos generales
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("registro", registro))
    app.add_handler(CommandHandler("menu", ver_menu))
    app.add_handler(CommandHandler("pedido", hacer_pedido))
    app.add_handler(CommandHandler("mispedidos", mis_pedidos))
    app.add_handler(CommandHandler("perfil", perfil))
    
    # Handlers de administración
    app.add_handler(CommandHandler("admin", admin_panel))
    app.add_handler(CommandHandler("agregar", agregar_producto))
    app.add_handler(CommandHandler("listaproductos", listar_productos))
    app.add_handler(CommandHandler("eliminar", eliminar_producto))
    app.add_handler(CommandHandler("disponible", cambiar_disponibilidad))
    app.add_handler(CommandHandler("pedidos", ver_pedidos))
    app.add_handler(CommandHandler("confirmar", confirmar_pedido))
    app.add_handler(CommandHandler("preparar", preparar_pedido))
    app.add_handler(CommandHandler("listo", pedido_listo))
    app.add_handler(CommandHandler("usuarios", listar_usuarios))
    
    # Handlers de fotos y botones
    app.add_handler(MessageHandler(filters.PHOTO, foto_handler))
    app.add_handler(CallbackQueryHandler(button_handler))
    
    print(f"{animar('bienvenida')}")
    print("☕ CafeteríaBot iniciado!")
    print(f"👥 Admins configurados: {len(ADMIN_IDS)}")
    print(f"📁 Base de datos: {DB_PATH}")
    print(f"🔍 OCR: {'Disponible' if OCR_AVAILABLE else 'NO DISPONIBLE'}")
    
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
