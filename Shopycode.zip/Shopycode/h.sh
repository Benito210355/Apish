# 1. Instalar dependencias
pip install python-telegram-bot pytesseract pillow opencv-python

# 2. Instalar Tesseract OCR (para español)
sudo apt update
sudo apt install tesseract-ocr tesseract-ocr-spa

# 3. Configurar el token
#    Reemplaza "AQUI_TU_TOKEN" con el token de @BotFather

# 4. Ejecutar
python3 cafeteria_bot.py
