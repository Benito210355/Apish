#!/usr/bin/env python3
"""
Shiro Shopify API v5.1 - TERMUX OPTIMIZED
Optimizado para Termux (Android) sin cambios en lógica/estructura
"""

import os
import sys
import time
import threading
import queue
import random
import logging
import signal
from flask import Flask, request, jsonify
from datetime import datetime
from shopifyapi import format_proxy, ShopifyAuto

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# FLASK APP - DEFINIR ANTES DE TODO USO
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
app = Flask(__name__)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TERMUX COMPATIBILITY LAYER
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Detectar Termux automáticamente
IS_TERMUX = 'com.termux' in os.environ.get('HOME', '').lower() or \
            os.path.exists('/data/data/com.termux/files/usr')

# Logger ligero - evita writes síncronos bloqueantes en Android
logger = logging.getLogger('ShiroAPI')
if IS_TERMUX:
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%H:%M:%S',
        stream=sys.stdout
    )
    for lib in ['selenium', 'urllib3', 'chardet']:
        logging.getLogger(lib).setLevel(logging.WARNING)
else:
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%H:%M:%S'
    )

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TERMUX-SPECIFIC BROWSER WRAPPER
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

try:
    from captcha_solver import (
        _get_or_create_browser, _kill_browser, _full_browser_checkout,
        _do_full_browser_checkout_sync, logger as cs_logger
    )
    HAS_CAPTCHA_SOLVER = True
    logger.info("[IMPORT] captcha_solver cargado correctamente")
except ImportError:
    HAS_CAPTCHA_SOLVER = False
    logger.warning("[IMPORT] captcha_solver no disponible - modo mock activo")
    
    def _get_or_create_browser():
        return None
    
    def _kill_browser():
        pass
    
    def _full_browser_checkout(browser, site):
        logger.info(f"[MOCK] Checkout en {site}")
        return True
    
    def _do_full_browser_checkout_sync(cc, mon, yr, cvv, info):
        logger.info(f"[MOCK] Pago con tarjeta ****{cc[-4:]}")
        return {"status": "Approved", "message": "Mock OK"}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# CONFIG
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

NUM_WORKERS = min(4, os.cpu_count() or 2) if IS_TERMUX else 8
TIMEOUT = 180 if IS_TERMUX else 120
MAX_QUEUE = 100 if IS_TERMUX else 200

logger.info(f"[TERMUX={'SI' if IS_TERMUX else 'NO'}] Workers={NUM_WORKERS} Timeout={TIMEOUT}s Queue={MAX_QUEUE}")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# WORKER POOL
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

_queue = queue.Queue()
_results = {}
_events = {}
_rlock = threading.Lock()
_running = False
_busy = [False] * NUM_WORKERS
_browser_lock = threading.Lock()


def _do_check(site, cc, mon, yr, cvv, info):
    """Run browser checkout."""
    with _browser_lock:
        try:
            browser = _get_or_create_browser()
            if not browser:
                return {"status": "Error", "message": "No browser"}
            
            ok = _full_browser_checkout(browser, site)
            if not ok:
                return {"status": "Error", "message": "Checkout blocked", "error_code": "CAPTCHA_REQUIRED"}
            
            result = _do_full_browser_checkout_sync(cc, mon, yr, cvv, info)
            return result
            
        except Exception as e:
            err = str(e)[:80]
            logger.error(f"Check error: {err}")
            if "session" in err.lower() or "disconnect" in err.lower() or "killed" in err.lower():
                try:
                    _kill_browser()
                except:
                    pass
            return {"status": "Error", "message": err}


def _worker(wid):
    global _running
    logger.info(f"[W{wid}] Ready")
    
    while _running:
        try:
            req = _queue.get(timeout=0.5)
        except queue.Empty:
            continue
        
        rid, site, cc, mon, yr, cvv, info = req
        _busy[wid] = True
        
        try:
            res = _do_check(site, cc, mon, yr, cvv, info)
        except Exception as e:
            res = {"status": "Error", "message": str(e)[:60]}
        
        _busy[wid] = False
        
        with _rlock:
            _results[rid] = res
            if rid in _events:
                _events[rid].set()
        
        _queue.task_done()


def _start():
    global _running
    if _running:
        logger.info("[API] Workers ya activos")
        return
    _running = True
    for i in range(NUM_WORKERS):
        t = threading.Thread(target=_worker, args=(i,), daemon=True)
        t.start()
    logger.info(f"[API] {NUM_WORKERS} workers started")


def _stop():
    global _running
    _running = False
    logger.info("[API] Deteniendo workers...")
    while not _queue.empty():
        try:
            _queue.get_nowait()
            _queue.task_done()
        except queue.Empty:
            break
    logger.info("[API] Workers detenidos")


def _check(site, card, proxy=None):
    _start()
    
    p = card.strip().replace(" ", "").split("|")
    if len(p) != 4:
        return {"status": "Error", "message": "Bad format"}
    cc, mon, yr, cvv = p
    if len(yr) == 2:
        yr = "20" + yr
    
    rid = f"{time.time()}_{random.randint(1000, 9999)}"
    ev = threading.Event()
    
    with _rlock:
        _events[rid] = ev
    
    info = ShopifyAuto().get_random_info()
    _queue.put((rid, site, cc, mon, yr, cvv, info))
    
    if ev.wait(timeout=TIMEOUT):
        with _rlock:
            _events.pop(rid, None)
            return _results.pop(rid, {"status": "Error", "message": "No result"})
    
    with _rlock:
        _events.pop(rid, None)
        _results.pop(rid, None)
    return {"status": "Error", "message": "Timeout"}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ENDPOINTS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@app.route('/shopify', methods=['GET'])
def shopify():
    site = request.args.get('site', '').strip()
    cc = request.args.get('cc', '').strip()
    proxy = request.args.get('proxy', '').strip()
    
    if not site or not cc or cc.count('|') != 3:
        return jsonify({"status": "Error", "message": "Bad params"}), 400
    
    qs = _queue.qsize()
    if qs > MAX_QUEUE:
        return jsonify({"status": "Error", "message": f"Busy ({qs})", "error_code": "SERVER_BUSY"})
    
    t0 = time.time()
    res = _check(site, cc, format_proxy(proxy) if proxy else None)
    elapsed = time.time() - t0
    
    out = {
        "status": res.get("status", "Error"),
        "message": res.get("message", ""),
        "error_code": res.get("error_code", ""),
        "price": res.get("price", ""),
        "product": res.get("product", ""),
        "gateway": "Shopify Payments",
        "time": f"{elapsed:.1f}s",
        "site": site.replace("https://", "").replace("http://", "").split("/")[0]
    }
    
    mask = cc[:6] + "****" + cc.split("|")[0][-4:] if len(cc) > 10 else "****"
    busy = sum(_busy)
    logger.info(f"{out['status']} | {mask} | {elapsed:.1f}s | q:{qs} w:{busy}")
    
    return jsonify(out)


@app.route('/health')
def health():
    return jsonify({
        "status": "ok", "v": "5.1",
        "workers": NUM_WORKERS,
        "busy": sum(_busy),
        "queue": _queue.qsize(),
        "termux": IS_TERMUX
    })


@app.route('/')
def index():
    return jsonify({
        "name": "Shiro API",
        "v": "5.1",
        "workers": NUM_WORKERS,
        "termux_optimized": IS_TERMUX
    })


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PRE-WARM
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _prewarm():
    if not HAS_CAPTCHA_SOLVER:
        logger.info("[PREWARM] captcha_solver no disponible - saltando")
        return
    try:
        t0 = time.time()
        b = _get_or_create_browser()
        if b:
            logger.info(f"[PREWARM] Browser listo en {time.time()-t0:.1f}s")
        else:
            logger.warning("[PREWARM] Browser no disponible")
    except Exception as e:
        logger.error(f"[PREWARM] Falló: {e}")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SIGNAL HANDLING
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _signal_handler(sig, frame):
    logger.info("[SHUTDOWN] Señal recibida, cerrando...")
    _stop()
    sys.exit(0)

signal.signal(signal.SIGINT, _signal_handler)
signal.signal(signal.SIGTERM, _signal_handler)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# MAIN
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

if __name__ == '__main__':
    logger.info(f"{'='*50}")
    logger.info(f"Shiro Shopify API v5.1 - TERMUX OPTIMIZED")
    logger.info(f"{'='*50}")
    logger.info(f"Entorno: {'Termux (Android)' if IS_TERMUX else 'Linux/Desktop'}")
    logger.info(f"Workers: {NUM_WORKERS} | Timeout: {TIMEOUT}s | Queue: {MAX_QUEUE}")
    logger.info(f"captcha_solver: {'DISPONIBLE' if HAS_CAPTCHA_SOLVER else 'NO DISPONIBLE (mock)'}")
    logger.info(f"{'='*50}")
    
    _prewarm()
    _start()
    
    host = '0.0.0.0'
    port = int(os.environ.get('PORT', 5000))
    
    logger.info(f"[API] Servidor en http://{host}:{port}")
    
    app.run(
        host=host,
        port=port,
        threaded=True,
        debug=False,
        use_reloader=False
    )
