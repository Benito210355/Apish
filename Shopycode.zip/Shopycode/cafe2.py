#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CaféBot v2.1 - Ultra-liviano para Termux (Android)
Sin torch, sin opencv - Solo PIL + Tesseract + Regex fallback
Telegram Bot: menú con fotos OCR, pedidos, roles y animaciones ASCII
Autorización verificada - Pentest autorizado
"""

import os
import re
import sys
import json
import sqlite3
import logging
import subprocess
import tempfile
from datetime import datetime
from functools import wraps
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ─── Detectar Termux ─────────────────────────────────────────────────────────
ES_TERMUX = "com.termux" in os.environ.get("PREFIX", "") or "/data/data/com.termux" in os.getcwd()

# ─── Telegram ────────────────────────────────────────────────────────────────
try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import (
        Application, CommandHandler, MessageHandler, CallbackQueryHandler,
        filters, ContextTypes
    )
    from telegram.constants import ParseMode
except ImportError:
    print("[!] Instalando python-telegram-bot...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "python-telegram-bot"])
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import (
        Application, CommandHandler, MessageHandler, CallbackQueryHandler,
        filters, ContextTypes
    )
    from telegram.constants import ParseMode

# ─── OCR Ligero ──────────────────────────────────────────────────────────────
OCR_DISPONIBLE = False
MODO_OCR = "ninguno"

# Opción 1: Tesseract (el más ligero para Termux)
TESSERACT_CMD = None
try:
    # Verificar si tesseract está instalado
    result = subprocess.run(["which", "tesseract"], capture_output=True, text=True)
    if result.stdout.strip():
        TESSERACT_CMD = result.stdout.strip()
        import pytesseract
        pytesseract.pytesseract.tesseract_cmd = TESSERACT_CMD
        from PIL import Image
        OCR_DISPONIBLE = True
        MODO_OCR = "tesseract"
        print(f"[✓] Tesseract encontrado en: {TESSERACT_CMD}")
except (ImportError, FileNotFoundError):
    pass

# Opción 2: OCR puro con Python + PIL (sin tesseract, sin torch)
if not OCR_DISPONIBLE:
    try:
        from PIL import Image
        import pytesseract  # Intentamos una vez más
    except ImportError:
        print("[!] PIL no encontrado. Instalando Pillow...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "Pillow"])
        from PIL import Image

# ─── Configuración ───────────────────────────────────────────────────────────
TOKEN = os.environ.get("BOT_TOKEN") or "8815662392:AAEXbjhB0IFCPL4WL1CKfWKw4jwy6ZjbN6A"

# Admin IDs desde variable de entorno o configuración directa
ADMIN_IDS_ENV = os.environ.get("ADMIN_IDS", "8128659179")
if ADMIN_IDS_ENV:
    ADMIN_IDS = [int(x.strip()) for x in ADMIN_IDS_ENV.split(",") if x.strip().isdigit()]
else:
    ADMIN_IDS = [123456789]  # ← CAMBIA ESTO POR TU ID DE TELEGRAM

# Rutas
if ES_TERMUX:
    DB_DIR = Path.home() / "cafeteria_bot"
    DB_DIR.mkdir(exist_ok=True)
    DB_PATH = str(DB_DIR / "cafeteria.db")
    FOTOS_DIR = DB_DIR / "fotos"
    FOTOS_DIR.mkdir(exist_ok=True)
    LOG_PATH = str(DB_DIR / "bot.log")
else:
    DB_PATH = "cafeteria.db"
    FOTOS_DIR = Path("fotos_menu")
    FOTOS_DIR.mkdir(exist_ok=True)
    LOG_PATH = "bot.log"

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.WARNING if ES_TERMUX else logging.INFO,
    filename=LOG_PATH if ES_TERMUX else None,
    filemode="a" if ES_TERMUX else None
)
logger = logging.getLogger(__name__)

# ─── Base de Datos ───────────────────────────────────────────────────────────

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            user_id INTEGER PRIMARY KEY,
            username TEXT DEFAULT '',
            nombre TEXT DEFAULT 'Usuario',
            rol TEXT DEFAULT 'cliente',
            direccion TEXT DEFAULT '',
            telefono TEXT DEFAULT '',
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS categorias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT UNIQUE NOT NULL
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            precio REAL NOT NULL,
            categoria_id INTEGER DEFAULT 1,
            descripcion TEXT DEFAULT '',
            disponible INTEGER DEFAULT 1,
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (categoria_id) REFERENCES categorias(id)
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS pedidos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            items TEXT NOT NULL,
            total REAL NOT NULL,
            estado TEXT DEFAULT 'pendiente',
            direccion TEXT DEFAULT '',
            notas TEXT DEFAULT '',
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES usuarios(user_id)
        )
    """)
    
    c.execute("INSERT OR IGNORE INTO categorias (id, nombre) VALUES (1, 'General')")
    
    for uid in ADMIN_IDS:
        c.execute("""
            INSERT OR IGNORE INTO usuarios (user_id, nombre, rol)
            VALUES (?, 'Admin', 'admin')
        """, (uid,))
    
    conn.commit()
    conn.close()

# ─── Animaciones ASCII ───────────────────────────────────────────────────────

ANIMACIONES = {
    "cafe": """
╔══════════════════╗
║   ☕ CAFETERÍA   ║
╚══════════════════╝""",
    "bienvenida": """
╔══════════════════╗
║   BIENVENIDO     ║
║ SISTEMA PEDIDOS  ║
╚══════════════════╝""",
    "pedido_recibido": """
╔══════════════════╗
║  PEDIDO RECIBIDO ║
║   PREPARANDO...  ║
╚══════════════════╝""",
    "listo": """
╔══════════════════╗
║  PEDIDO LISTO!   ║
║   DISFRUTA!      ║
╚══════════════════╝""",
    "error": """
╔══════════════════╗
║     ERROR!       ║
╚══════════════════╝""",
    "cargando": """
╔══════════════════╗
║  PROCESANDO...   ║
║  ████░░░░ 40%   ║
╚══════════════════╝"""
}

def animar(frame_name: str) -> str:
    return f"<pre>{ANIMACIONES.get(frame_name, '')}</pre>"

# ─── Decoradores ────────────────────────────────────────────────────────────

def solo_admin(func):
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT rol FROM usuarios WHERE user_id = ?", (user_id,))
        row = c.fetchone()
        conn.close()
        if not row or row[0] not in ('admin', 'superadmin'):
            await update.message.reply_text(
                f"{animar('error')}\n⛔ Solo administradores.",
                parse_mode=ParseMode.HTML
            )
            return
        return await func(update, context, *args, **kwargs)
    return wrapper

# ─── OCR con Tesseract (liviano para Termux) ─────────────────────────────────

def preprocess_image_pil(image_path: str) -> Optional['Image.Image']:
    """
    Preprocesa imagen usando solo PIL (sin opencv)
    Aumenta contraste y convierte a escala de grises
    """
    try:
        img = Image.open(image_path)
        # Convertir a escala de grises
        img = img.convert('L')
        # Aumentar contraste (threshold simple)
        img = img.point(lambda x: 0 if x < 128 else 255)
        return img
    except Exception as e:
        logger.error(f"Error preprocesando imagen: {e}")
        return None

def ocr_con_tesseract(image_path: str) -> str:
    """OCR usando Tesseract"""
    try:
        img = preprocess_image_pil(image_path)
        if img is None:
            return ""
        
        # Configuración para menús
        config = '--psm 6 -l spa+eng --oem 1'
        texto = pytesseract.image_to_string(img, config=config)
        return texto
    except Exception as e:
        logger.error(f"Error en Tesseract OCR: {e}")
        return ""

def ocr_sin_tesseract(image_path: str) -> str:
    """
    OCR de emergencia sin Tesseract.
    Usa PIL para leer píxeles y extraer texto mediante patrones.
    Esto es un fallback MUY básico para cuando no hay Tesseract.
    """
    try:
        from PIL import Image
        img = Image.open(image_path)
        img = img.convert('L').point(lambda x: 0 if x < 128 else 255)
        
        # Extraer "texto" de píxeles - esto es limitado
        # En realidad, sin Tesseract no podemos hacer OCR real
        # Pero intentamos extraer información básica
        
        width, height = img.size
        pixels = list(img.getdata())
        
        # Detectar si la imagen tiene algo de contenido
        non_white = sum(1 for p in pixels if p < 200)
        total = len(pixels)
        
        if non_white / total < 0.95:  # Si hay contenido
            # No podemos hacer OCR real sin tesseract
            # Retornamos string vacío para que use el modo manual
            return ""
        return ""
    except Exception as e:
        logger.error(f"Error en OCR fallback: {e}")
        return ""

def extraer_productos_de_texto(texto: str) -> List[Dict]:
    """
    Extrae productos del texto OCR usando regex.
    Sin importar cómo se obtuvo el texto.
    """
    productos = []
    lineas = texto.strip().split('\n')
    
    # Múltiples patrones para diferentes formatos de menú
    patrones = [
        # "Nombre $12.50" o "Nombre 12.50"
        re.compile(r'^[\s]*[\-\•\*]?\s*(.+?)\s+\$?\s*([0-9]+[.,]?[0-9]*)\s*$', re.UNICODE),
        # "$12.50 Nombre"
        re.compile(r'^\$?\s*([0-9]+[.,]?[0-9]*)\s+(.+?)\s*$', re.UNICODE),
        # "Nombre - $12.50"
        re.compile(r'^[\s]*[\-\•\*]?\s*(.+?)\s*[\-\:]\s*\$?\s*([0-9]+[.,]?[0-9]*)\s*$', re.UNICODE),
    ]
    
    visto = set()
    
    for linea in lineas:
        linea = linea.strip()
        if not linea or len(linea) < 4:
            continue
        
        nombre = None
        precio_str = None
        
        for patron in patrones:
            match = patron.match(linea)
            if match:
                if len(match.groups()) == 2:
                    g1, g2 = match.groups()
                    # Determinar cuál es nombre y cuál precio
                    if patron == patrones[1]:  # Inverso: precio primero
                        precio_str, nombre = g1, g2
                    else:
                        nombre, precio_str = g1, g2
                break
        
        if nombre and precio_str:
            try:
                precio_str_clean = precio_str.replace(',', '.')
                precio = float(precio_str_clean)
                
                if 0.10 <= precio <= 999.99:
                    nombre = re.sub(r'[^\w\sáéíóúñüÁÉÍÓÚÑÜ]', '', nombre).strip()
                    
                    if nombre and len(nombre) > 1:
                        key = nombre.lower().strip()
                        if key not in visto:
                            visto.add(key)
                            productos.append({
                                "nombre": nombre,
                                "precio": round(precio, 2)
                            })
            except ValueError:
                continue
    
    return productos

def procesar_imagen_menu(image_path: str) -> List[Dict]:
    """
    Procesa imagen del menú.
    Intenta Tesseract primero, fallback a regex básico.
    """
    productos = []
    
    # Intentar OCR con Tesseract
    if MODO_OCR == "tesseract":
        texto = ocr_con_tesseract(image_path)
        if texto.strip():
            productos = extraer_productos_de_texto(texto)
            if productos:
                return productos
    
    # Fallback: intentar modo manual
    return []

# ─── Handlers de Comandos ───────────────────────────────────────────────────

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO usuarios (user_id, username, nombre)
        VALUES (?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            username = excluded.username,
            nombre = excluded.nombre
    """, (user.id, user.username or "", user.first_name or ""))
    conn.commit()
    conn.close()
    
    await update.message.reply_text(
        f"{animar('bienvenida')}\n"
        f"☕ ¡Bienvenido {user.first_name}!\n\n"
        f"📋 /menu - Ver menú\n"
        f"🛒 /pedido - Hacer pedido\n"
        f"📦 /mispedidos - Mis pedidos\n"
        f"👤 /perfil - Mi perfil\n"
        f"🔐 /admin - Panel admin",
        parse_mode=ParseMode.HTML
    )

async def registro(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    args = context.args
    
    if len(args) < 1:
        await update.message.reply_text(
            "Uso: /registro <nombre> [dirección] [teléfono]\n"
            "Ej: /registro Juan \"Calle 123\" 5551234"
        )
        return
    
    nombre = args[0]
    direccion = args[1] if len(args) > 1 else ""
    telefono = args[2] if len(args) > 2 else ""
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO usuarios (user_id, username, nombre, direccion, telefono)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            nombre = excluded.nombre,
            direccion = excluded.direccion,
            telefono = excluded.telefono
    """, (user.id, user.username or "", nombre, direccion, telefono))
    conn.commit()
    conn.close()
    
    await update.message.reply_text(
        f"✅ Registro:\n👤 {nombre}\n📍 {direccion}\n📞 {telefono}"
    )

async def ver_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT p.nombre, p.precio, c.nombre 
        FROM productos p
        LEFT JOIN categorias c ON p.categoria_id = c.id
        WHERE p.disponible = 1
        ORDER BY c.nombre, p.nombre
    """)
    productos = c.fetchall()
    conn.close()
    
    if not productos:
        await update.message.reply_text(
            f"{animar('error')}\n📭 Menú vacío. Admin: /agregar o envía foto.",
            parse_mode=ParseMode.HTML
        )
        return
    
    categorias = {}
    for nombre, precio, cat in productos:
        cat = cat or "General"
        if cat not in categorias:
            categorias[cat] = []
        categorias[cat].append((nombre, precio))
    
    mensaje = f"{animar('cafe')}\n📋 **MENÚ**\n\n"
    for cat, items in categorias.items():
        mensaje += f"**{cat.upper()}**\n"
        for nombre, precio in items:
            mensaje += f"  • {nombre} — ${precio:.2f}\n"
        mensaje += "\n"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

async def hacer_pedido(update: Update, context: ContextTypes.DEFAULT_TYPE):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT id, nombre, precio FROM productos WHERE disponible = 1 ORDER BY nombre")
    productos = c.fetchall()
    conn.close()
    
    if not productos:
        await update.message.reply_text(
            f"{animar('error')}\n📭 No hay productos disponibles.",
            parse_mode=ParseMode.HTML
        )
        return
    
    keyboard = []
    row = []
    for i, (pid, nombre, precio) in enumerate(productos):
        btn_text = f"{nombre[:15]} ${precio:.2f}"
        row.append(InlineKeyboardButton(btn_text, callback_data=f"p_{pid}"))
        if (i + 1) % 2 == 0 or i == len(productos) - 1:
            keyboard.append(row)
            row = []
    
    keyboard.append([
        InlineKeyboardButton("✅ Finalizar", callback_data="fin"),
        InlineKeyboardButton("❌ Cancelar", callback_data="can")
    ])
    
    context.user_data['carrito'] = []
    
    await update.message.reply_text(
        f"{animar('pedido_recibido')}\n"
        "🛒 **NUEVO PEDIDO**\n"
        "Toca para agregar:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.HTML
    )

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "can":
        context.user_data['carrito'] = []
        await query.edit_message_text("❌ Pedido cancelado.")
        return
    
    if data == "fin":
        carrito = context.user_data.get('carrito', [])
        if not carrito:
            await query.edit_message_text("❌ Carrito vacío.")
            return
        
        total = sum(item['precio'] for item in carrito)
        user_id = update.effective_user.id
        
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("""
            INSERT INTO pedidos (user_id, items, total, estado)
            VALUES (?, ?, ?, 'pendiente')
        """, (user_id, json.dumps(carrito, ensure_ascii=False), total))
        pedido_id = c.lastrowid
        conn.commit()
        conn.close()
        
        resumen = f"{animar('listo')}\n"
        resumen += f"✅ **Pedido #{pedido_id}**\n\n"
        for item in carrito:
            resumen += f"• {item['nombre']} — ${item['precio']:.2f}\n"
        resumen += f"\n💰 **Total: ${total:.2f}**\n⏳ Espera confirmación."
        
        await query.edit_message_text(resumen, parse_mode=ParseMode.MARKDOWN)
        
        for admin_id in ADMIN_IDS:
            try:
                await context.bot.send_message(
                    admin_id,
                    f"📦 **Pedido #{pedido_id}**\n"
                    f"👤 {update.effective_user.first_name}\n"
                    f"💰 ${total:.2f}\n"
                    f"/confirmar {pedido_id}\n/listo {pedido_id}",
                    parse_mode=ParseMode.MARKDOWN
                )
            except:
                pass
        
        context.user_data['carrito'] = []
        return
    
    if data.startswith("p_"):
        prod_id = int(data.split("_")[1])
        
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT nombre, precio FROM productos WHERE id = ?", (prod_id,))
        row = c.fetchone()
        conn.close()
        
        if row:
            nombre, precio = row
            if 'carrito' not in context.user_data:
                context.user_data['carrito'] = []
            
            context.user_data['carrito'].append({
                'id': prod_id, 'nombre': nombre, 'precio': precio
            })
            
            total = sum(i['precio'] for i in context.user_data['carrito'])
            
            await query.edit_message_text(
                f"✅ **{nombre}** (${precio:.2f})\n💰 Total: **${total:.2f}**\n\n"
                "Más productos o Finalizar:",
                reply_markup=query.message.reply_markup,
                parse_mode=ParseMode.MARKDOWN
            )

async def mis_pedidos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT id, items, total, estado, creado_en 
        FROM pedidos WHERE user_id = ? 
        ORDER BY creado_en DESC LIMIT 5
    """, (user_id,))
    pedidos = c.fetchall()
    conn.close()
    
    if not pedidos:
        await update.message.reply_text("📭 Sin pedidos. Usa /pedido.")
        return
    
    emojis = {'pendiente': '⏳', 'confirmado': '✅', 'preparando': '👨‍🍳', 
              'listo': '🎉', 'entregado': '📦'}
    
    mensaje = "📋 **MIS PEDIDOS**\n\n"
    for pid, items_json, total, estado, fecha in pedidos:
        items = json.loads(items_json)
        items_str = ", ".join([i['nombre'] for i in items])
        emoji = emojis.get(estado, '❓')
        mensaje += f"#{pid} {emoji} {estado.upper()}\n   {items_str}\n   💰 ${total:.2f}\n\n"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

async def perfil(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT nombre, rol, direccion, telefono FROM usuarios WHERE user_id = ?", (user_id,))
    row = c.fetchone()
    conn.close()
    
    if not row:
        await update.message.reply_text("Usa /registro para crear perfil.")
        return
    
    nombre, rol, direccion, telefono = row
    await update.message.reply_text(
        f"{animar('cafe')}\n👤 **{nombre}**\n🔐 Rol: {rol}\n📍 {direccion or 'Sin dirección'}\n📞 {telefono or 'Sin teléfono'}",
        parse_mode=ParseMode.HTML
    )

# ─── Comandos Admin ─────────────────────────────────────────────────────────

@solo_admin
async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        f"{animar('bienvenida')}\n"
        f"🔐 **PANEL ADMIN**\n\n"
        f"📸 Envía **foto del menú** → OCR\n"
        f"📝 /agregar <nom> <precio> [cat]\n"
        f"📋 /lista - Productos\n"
        f"❌ /eliminar <id>\n"
        f"🔄 /toggle <id>\n"
        f"📦 /pedidos - Pendientes\n"
        f"✅ /confirmar <id>\n"
        f"👨‍🍳 /preparar <id>\n"
        f"🎉 /listo <id>\n"
        f"👥 /usuarios",
        parse_mode=ParseMode.MARKDOWN
    )

@solo_admin
async def agregar_producto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    if len(args) < 2:
        await update.message.reply_text(
            "Uso: /agregar \"Café Latte\" 3.50 [Bebidas]\n"
            "O envía foto del menú para OCR automático."
        )
        return
    
    nombre = args[0]
    try:
        precio = float(args[1].replace(',', '.'))
    except ValueError:
        await update.message.reply_text("❌ Precio inválido")
        return
    
    cat = args[2] if len(args) > 2 else "General"
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("INSERT OR IGNORE INTO categorias (nombre) VALUES (?)", (cat,))
    c.execute("SELECT id FROM categorias WHERE nombre = ?", (cat,))
    cat_id = c.fetchone()[0]
    
    c.execute("INSERT INTO productos (nombre, precio, categoria_id) VALUES (?, ?, ?)",
              (nombre, precio, cat_id))
    conn.commit()
    conn.close()
    
    await update.message.reply_text(f"✅ {nombre} — ${precio:.2f} [{cat}]")

@solo_admin
async def lista_productos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT p.id, p.nombre, p.precio, c.nombre, p.disponible
        FROM productos p LEFT JOIN categorias c ON p.categoria_id = c.id
        ORDER BY p.nombre
    """)
    productos = c.fetchall()
    conn.close()
    
    if not productos:
        await update.message.reply_text("📭 No hay productos.")
        return
    
    mensaje = "📋 **PRODUCTOS**\n\n"
    for pid, nombre, precio, cat, disp in productos:
        icono = "✅" if disp else "❌"
        mensaje += f"{icono} `#{pid}` {nombre} — ${precio:.2f} [{cat}]\n"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

@solo_admin
async def eliminar_producto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Uso: /eliminar <id>")
        return
    try:
        pid = int(context.args[0])
    except:
        await update.message.reply_text("❌ ID inválido")
        return
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("DELETE FROM productos WHERE id = ?", (pid,))
    ok = c.rowcount > 0
    conn.commit()
    conn.close()
    
    await update.message.reply_text(f"{'✅' if ok else '❌'} #{pid}{' eliminado' if ok else ' no encontrado'}.")

@solo_admin
async def toggle_producto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Uso: /toggle <id>")
        return
    try:
        pid = int(context.args[0])
    except:
        await update.message.reply_text("❌ ID inválido")
        return
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT disponible FROM productos WHERE id = ?", (pid,))
    row = c.fetchone()
    if not row:
        await update.message.reply_text("❌ No encontrado")
        conn.close()
        return
    
    nuevo = 0 if row[0] else 1
    c.execute("UPDATE productos SET disponible = ? WHERE id = ?", (nuevo, pid))
    conn.commit()
    conn.close()
    
    await update.message.reply_text(f"✅ #{pid} {'disponible' if nuevo else 'no disponible'}")

@solo_admin
async def ver_pedidos_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT p.id, u.nombre, p.items, p.total, p.estado
        FROM pedidos p JOIN usuarios u ON p.user_id = u.user_id
        WHERE p.estado IN ('pendiente', 'confirmado', 'preparando')
        ORDER BY p.creado_en ASC LIMIT 5
    """)
    pedidos = c.fetchall()
    conn.close()
    
    if not pedidos:
        await update.message.reply_text("📭 Sin pedidos pendientes.")
        return
    
    emojis = {'pendiente': '⏳', 'confirmado': '✅', 'preparando': '👨‍🍳'}
    mensaje = "📦 **PEDIDOS**\n\n"
    for pid, nombre, items_json, total, estado in pedidos:
        items = json.loads(items_json)
        items_str = ", ".join([i['nombre'] for i in items])
        emoji = emojis.get(estado, '❓')
        mensaje += f"#{pid} {emoji} {estado.upper()} — {nombre}\n   {items_str}\n   💰 ${total:.2f}\n\n"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

@solo_admin
async def gestionar_estado(update: Update, context: ContextTypes.DEFAULT_TYPE, estado: str):
    if not context.args:
        await update.message.reply_text(f"Uso: /{estado} <id>")
        return
    try:
        pid = int(context.args[0])
    except:
        await update.message.reply_text("❌ ID inválido")
        return
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT user_id, items, total FROM pedidos WHERE id = ?", (pid,))
    row = c.fetchone()
    if not row:
        await update.message.reply_text("❌ No encontrado")
        conn.close()
        return
    
    user_id, items_json, total = row
    c.execute("UPDATE pedidos SET estado = ? WHERE id = ?", (estado, pid))
    conn.commit()
    conn.close()
    
    msgs = {'confirmado': '✅ Confirmado', 'preparando': '👨‍🍳', 'listo': '🎉 Listo'}
    await update.message.reply_text(f"{msgs.get(estado, estado)} #{pid}")
    
    try:
        items = json.loads(items_json)
        items_str = "\n".join([f"• {i['nombre']}" for i in items])
        await context.bot.send_message(
            user_id,
            f"📦 **Pedido #{pid}**\nEstado: **{estado.upper()}**\n\n{items_str}\n💰 ${total:.2f}"
        )
    except:
        pass

@solo_admin
async def confirmar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await gestionar_estado(update, context, 'confirmado')

@solo_admin
async def preparar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await gestionar_estado(update, context, 'preparando')

@solo_admin
async def listo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await gestionar_estado(update, context, 'listo')

@solo_admin
async def listar_usuarios(update: Update, context: ContextTypes.DEFAULT_TYPE):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT user_id, nombre, rol FROM usuarios ORDER BY nombre")
    usuarios = c.fetchall()
    conn.close()
    
    if not usuarios:
        await update.message.reply_text("Sin usuarios.")
        return
    
    mensaje = "👥 **USUARIOS**\n\n"
    for uid, nombre, rol in usuarios:
        mensaje += f"`{uid}` **{nombre}** ({rol})\n"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

# ─── Handler de Fotos ───────────────────────────────────────────────────────

async def foto_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Procesa fotos del menú enviadas por admins"""
    user_id = update.effective_user.id
    
    # Verificar admin
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT rol FROM usuarios WHERE user_id = ?", (user_id,))
    row = c.fetchone()
    conn.close()
    
    if not row or row[0] not in ('admin', 'superadmin'):
        await update.message.reply_text(
            f"{animar('error')}\n⛔ Solo admins pueden subir menús.",
            parse_mode=ParseMode.HTML
        )
        return
    
    # Descargar foto
    photo_file = await update.message.photo[-1].get_file()
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    photo_path = str(FOTOS_DIR / f"menu_{user_id}_{timestamp}.jpg")
    await photo_file.download_to_drive(photo_path)
    
    msg = await update.message.reply_text(
        f"{animar('cargando')}\n🔍 Procesando menú...",
        parse_mode=ParseMode.HTML
    )
    
    # Extraer productos
    productos = procesar_imagen_menu(photo_path)
    
    # Limpiar foto
    try:
        os.remove(photo_path)
    except:
        pass
    
    if not productos:
        await msg.edit_text(
            f"{animar('error')}\n"
            "❌ No se pudieron extraer productos.\n\n"
            "Sugerencias:\n"
            "• Foto clara, bien iluminada\n"
            "• Formato: \"Nombre $12.50\"\n"
            f"{'• Instala tesseract: pkg install tesseract' if not OCR_DISPONIBLE else ''}\n"
            "• Usa /agregar manualmente",
            parse_mode=ParseMode.HTML
        )
        return
    
    # Guardar en BD
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    nuevos = 0
    existentes = 0
    for prod in productos:
        c.execute("SELECT id FROM productos WHERE nombre = ?", (prod['nombre'],))
        if not c.fetchone():
            c.execute("INSERT INTO productos (nombre, precio) VALUES (?, ?)",
                      (prod['nombre'], prod['precio']))
            nuevos += 1
        else:
            existentes += 1
    
    conn.commit()
    conn.close()
    
    resumen = f"✅ **Menú procesado**\n\n"
    resumen += f"📸 Detectados: {len(productos)}\n"
    resumen += f"➕ Nuevos: {nuevos}\n"
    resumen += f"🔁 Ya existían: {existentes}\n\n"
    
    if productos:
        resumen += "**Productos encontrados:**\n"
        for i, prod in enumerate(productos[:10], 1):
            resumen += f"{i}. {prod['nombre']} — ${prod['precio']:.2f}\n"
        if len(productos) > 10:
            resumen += f"... y {len(productos)-10} más\n"
    
    resumen += "\n📋 /menu para ver el menú completo"
    
    await msg.edit_text(resumen, parse_mode=ParseMode.MARKDOWN)

# ─── Instalación para Termux ────────────────────────────────────────────────

def instalar_termux():
    print("""
╔══════════════════════════════════════╗
║  ☕ CAFETERÍA BOT - INSTALADOR       ║
║  Optimizado para Termux (sin torch)  ║
╚══════════════════════════════════════╝
""")
    print("[*] Autorización verificada - Pentest autorizado")
    print("[*] Instalando dependencias...\n")
    
    # Paquetes del sistema (tesseract para OCR)
    print("[1/4] Instalando tesseract-ocr...")
    subprocess.run(["pkg", "update", "-y"], capture_output=True)
    result = subprocess.run(["pkg", "install", "-y", "tesseract"], capture_output=True, text=True)
    if result.returncode == 0:
        print("[✓] Tesseract instalado")
    else:
        print("[!] No se pudo instalar tesseract, el OCR usará modo manual")
    
    # Idiomas de tesseract
    print("[2/4] Instalando idioma español para OCR...")
    subprocess.run(["pkg", "install", "-y", "tesseract-data-spa"], capture_output=True)
    
    # Dependencias Python (solo las mínimas)
    print("[3/4] Instalando dependencias Python...")
    subprocess.check_call([
        sys.executable, "-m", "pip", "install",
        "python-telegram-bot", "Pillow", "pytesseract"
    ])
    print("[✓] Dependencias Python instaladas")
    
    # Directorio
    print("[4/4] Creando directorio de datos...")
    db_dir = Path.home() / "cafeteria_bot"
    db_dir.mkdir(exist_ok=True)
    (db_dir / "fotos").mkdir(exist_ok=True)
    print(f"[✓] Directorio: {db_dir}")
    
    print("""
╔══════════════════════════════════════╗
║  INSTALACIÓN COMPLETA                ║
╠══════════════════════════════════════╣
║                                      ║
║  Para ejecutar el bot:               ║
║                                      ║
║  export BOT_TOKEN='tu_token'         ║
║  export ADMIN_IDS='tu_id'            ║
║  python3 cafeteria_bot.py            ║
║                                      ║
║  O usa run.sh para inicio rápido:    ║
║  ./run.sh                            ║
║                                      ║
╚══════════════════════════════════════╝
""")
    
    # Crear script de inicio
    script = f"""#!/data/data/com.termux/files/usr/bin/bash
# CaféBot - Script de inicio
export BOT_TOKEN='AQUI_TU_TOKEN'
export ADMIN_IDS='AQUI_TU_ID'
cd {Path.cwd()}
echo "☕ Iniciando CaféBot..."
python3 {__file__}
"""
    with open("run.sh", "w") as f:
        f.write(script)
    os.chmod("run.sh", 0o755)
    print("[*] Creado run.sh - edítalo con tu token e ID")
    print()
    sys.exit(0)

# ─── Main ────────────────────────────────────────────────────────────────────

def main():
    if "--install" in sys.argv:
        instalar_termux()
        return
    
    # Inicializar BD
    init_db()
    
    # Verificar token
    if TOKEN == "AQUI_TU_TOKEN":
        print("[!] Configura tu token:")
        print("    export BOT_TOKEN='tu_token_de_botfather'")
        print("  O edita la variable TOKEN en el código.")
        print("  O ejecuta: python3 bot.py --install")
        sys.exit(1)
    
    if not ADMIN_IDS or ADMIN_IDS == [123456789]:
        print("[!] Configura ADMIN_IDS:")
        print("    export ADMIN_IDS='tu_id_telegram'")
        sys.exit(1)
    
    app = Application.builder().token(TOKEN).build()
    
    # Handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("registro", registro))
    app.add_handler(CommandHandler("menu", ver_menu))
    app.add_handler(CommandHandler("pedido", hacer_pedido))
    app.add_handler(CommandHandler("mispedidos", mis_pedidos))
    app.add_handler(CommandHandler("perfil", perfil))
    
    app.add_handler(CommandHandler("admin", admin_panel))
    app.add_handler(CommandHandler("agregar", agregar_producto))
    app.add_handler(CommandHandler("lista", lista_productos))
    app.add_handler(CommandHandler("eliminar", eliminar_producto))
    app.add_handler(CommandHandler("toggle", toggle_producto))
    app.add_handler(CommandHandler("pedidos", ver_pedidos_admin))
    app.add_handler(CommandHandler("confirmar", confirmar))
    app.add_handler(CommandHandler("preparar", preparar))
    app.add_handler(CommandHandler("listo", listo))
    app.add_handler(CommandHandler("usuarios", listar_usuarios))
    
    app.add_handler(MessageHandler(filters.PHOTO, foto_handler))
    app.add_handler(CallbackQueryHandler(button_handler))
    
    print("""
╔══════════════════════════╗
║   ☕ CAFETERÍA BOT v2.1 ║
║   Optimizado para Termux ║
╚══════════════════════════╝
""")
    print(f"✓ Base de datos: {DB_PATH}")
    print(f"✓ OCR: {MODO_OCR}")
    print(f"✓ Admins: {len(ADMIN_IDS)}")
    print(f"✓ Bot iniciado. Ctrl+C para detener.\n")
    
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
