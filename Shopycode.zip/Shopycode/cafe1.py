#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CaféBot v2.0 - Optimizado para Termux (Android)
Sistema de gestión de menú y pedidos para cafetería
Telegram Bot con roles, OCR de productos y animaciones ASCII
Autorización verificada - Prueba de penetración autorizada
"""

import os
import re
import sys
import json
import sqlite3
import logging
import asyncio
import subprocess
from datetime import datetime
from functools import wraps
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ─── Detectar Termux ─────────────────────────────────────────────────────────
ES_TERMUX = "com.termux" in os.environ.get("PREFIX", "") or "/data/data/com.termux" in os.getcwd()

# ─── Telegram imports ────────────────────────────────────────────────────────
try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import (
        Application, CommandHandler, MessageHandler, CallbackQueryHandler,
        filters, ContextTypes
    )
    from telegram.constants import ParseMode
except ImportError:
    print("[!] Instalando python-telegram-bot...")
    subprocess.run([sys.executable, "-m", "pip", "install", "python-telegram-bot"], check=True)
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import (
        Application, CommandHandler, MessageHandler, CallbackQueryHandler,
        filters, ContextTypes
    )
    from telegram.constants import ParseMode

# ─── OCR disponibles ─────────────────────────────────────────────────────────
OCR_DISPONIBLE = False
MODO_OCR = "ninguno"

# Intentar EasyOCR (preferido para Termux, no requiere Tesseract)
try:
    import easyocr
    OCR_DISPONIBLE = True
    MODO_OCR = "easyocr"
    print("[✓] EasyOCR cargado correctamente")
except ImportError:
    try:
        # Fallback a Tesseract si está instalado
        import pytesseract
        from PIL import Image
        import cv2
        import numpy as np
        # Verificar si tesseract existe
        if ES_TERMUX:
            tesseract_path = subprocess.run(
                ["which", "tesseract"], capture_output=True, text=True
            ).stdout.strip()
            if tesseract_path:
                pytesseract.pytesseract.tesseract_cmd = tesseract_path
                OCR_DISPONIBLE = True
                MODO_OCR = "tesseract"
                print("[✓] Tesseract OCR cargado")
        else:
            OCR_DISPONIBLE = True
            MODO_OCR = "tesseract"
    except ImportError:
        print("[!] OCR no disponible. Usa: pip install easyocr")

# ─── Configuración ───────────────────────────────────────────────────────────
# El token se lee de variable de entorno por seguridad
TOKEN = os.environ.get("BOT_TOKEN") or "8815662392:AAEXbjhB0IFCPL4WL1CKfWKw4jwy6ZjbN6A"

# IDs de administradores (múltiples separados por coma en variable de entorno)
ADMIN_IDS_ENV = os.environ.get("ADMIN_IDS", "8128659179")
if ADMIN_IDS_ENV:
    ADMIN_IDS = [int(x.strip()) for x in ADMIN_IDS_ENV.split(",") if x.strip().isdigit()]
else:
    ADMIN_IDS = [123456789]  # Reemplazar con tu ID

# Rutas adaptadas para Termux
if ES_TERMUX:
    DB_DIR = Path.home() / "cafeteria_bot"
    DB_DIR.mkdir(exist_ok=True)
    DB_PATH = str(DB_DIR / "cafeteria.db")
    FOTOS_DIR = DB_DIR / "fotos"
    FOTOS_DIR.mkdir(exist_ok=True)
    LOG_PATH = str(DB_DIR / "bot.log")
else:
    DB_PATH = "cafeteria.db"
    FOTOS_DIR = Path("fotos_menu")
    FOTOS_DIR.mkdir(exist_ok=True)
    LOG_PATH = "bot.log"

# Logging optimizado (menos verboso en Termux)
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.WARNING if ES_TERMUX else logging.INFO,
    filename=LOG_PATH if ES_TERMUX else None,
    filemode="a" if ES_TERMUX else None
)
logger = logging.getLogger(__name__)

# ─── Base de Datos ───────────────────────────────────────────────────────────

def init_db():
    """Inicializa la base de datos SQLite"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Usuarios
    c.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            user_id INTEGER PRIMARY KEY,
            username TEXT DEFAULT '',
            nombre TEXT DEFAULT 'Usuario',
            rol TEXT DEFAULT 'cliente',
            direccion TEXT DEFAULT '',
            telefono TEXT DEFAULT '',
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Categorías
    c.execute("""
        CREATE TABLE IF NOT EXISTS categorias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT UNIQUE NOT NULL
        )
    """)
    
    # Productos
    c.execute("""
        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            precio REAL NOT NULL,
            categoria_id INTEGER DEFAULT 1,
            descripcion TEXT DEFAULT '',
            disponible INTEGER DEFAULT 1,
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (categoria_id) REFERENCES categorias(id)
        )
    """)
    
    # Pedidos
    c.execute("""
        CREATE TABLE IF NOT EXISTS pedidos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            items TEXT NOT NULL,
            total REAL NOT NULL,
            estado TEXT DEFAULT 'pendiente',
            direccion TEXT DEFAULT '',
            notas TEXT DEFAULT '',
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES usuarios(user_id)
        )
    """)
    
    # Categoría por defecto
    c.execute("INSERT OR IGNORE INTO categorias (id, nombre) VALUES (1, 'General')")
    
    # Crear admins
    for uid in ADMIN_IDS:
        c.execute("""
            INSERT OR IGNORE INTO usuarios (user_id, nombre, rol)
            VALUES (?, 'Admin', 'admin')
        """, (uid,))
    
    conn.commit()
    conn.close()

# ─── Animaciones ASCII Optimizadas ───────────────────────────────────────────

ANIMACIONES = {
    "cafe": """
╔══════════════════╗
║   ☕ CAFETERÍA   ║
╚══════════════════╝""",
    "bienvenida": """
╔══════════════════╗
║   BIENVENIDO     ║
║ SISTEMA PEDIDOS  ║
╚══════════════════╝""",
    "pedido_recibido": """
╔══════════════════╗
║  PEDIDO RECIBIDO ║
║   PREPARANDO...  ║
╚══════════════════╝""",
    "listo": """
╔══════════════════╗
║  PEDIDO LISTO!   ║
║   DISFRUTA!      ║
╚══════════════════╝""",
    "error": """
╔══════════════════╗
║     ERROR!       ║
╚══════════════════╝""",
    "cargando": """
╔══════════════════╗
║  PROCESANDO...   ║
║  ████░░░░ 40%   ║
╚══════════════════╝"""
}

def animar(frame_name: str) -> str:
    """Devuelve animación ASCII formateada"""
    return f"<pre>{ANIMACIONES.get(frame_name, '')}</pre>"

# ─── Decoradores de Autorización ────────────────────────────────────────────

def solo_admin(func):
    """Decorador: solo admins pueden ejecutar el comando"""
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT rol FROM usuarios WHERE user_id = ?", (user_id,))
        row = c.fetchone()
        conn.close()
        
        if not row or row[0] not in ('admin', 'superadmin'):
            await update.message.reply_text(
                f"{animar('error')}\n⛔ Solo administradores.",
                parse_mode=ParseMode.HTML
            )
            return
        return await func(update, context, *args, **kwargs)
    return wrapper

def solo_cliente(func):
    """Decorador: solo clientes registrados"""
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT rol FROM usuarios WHERE user_id = ?", (user_id,))
        row = c.fetchone()
        conn.close()
        
        if not row:
            await update.message.reply_text(
                f"{animar('error')}\nRegístrate con /registro",
                parse_mode=ParseMode.HTML
            )
            return
        return await func(update, context, *args, **kwargs)
    return wrapper

# ─── OCR con EasyOCR (optimizado para Termux) ───────────────────────────────

def procesar_imagen_menu(image_path: str) -> List[Dict]:
    """
    Procesa imagen del menú y extrae productos usando OCR
    Retorna: [{"nombre": "Café", "precio": 3.50}, ...]
    """
    if not OCR_DISPONIBLE:
        return []
    
    productos = []
    
    try:
        if MODO_OCR == "easyocr":
            # EasyOCR - mejor para Termux, no requiere Tesseract
            reader = easyocr.Reader(['es', 'en'], gpu=False)
            resultados = reader.readtext(image_path, paragraph=True)
            
            texto_completo = " ".join([res[1] for res in resultados])
            
        elif MODO_OCR == "tesseract":
            import cv2
            from PIL import Image
            
            img = cv2.imread(image_path)
            if img is None:
                return []
            
            # Preprocesamiento
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
            
            config = '--psm 6 -l spa+eng'
            texto_completo = pytesseract.image_to_string(thresh, config=config)
        else:
            return []
        
        # Patrones de precios en menús
        lineas = texto_completo.strip().split('\n')
        
        # Patrón: Nombre $12.50 o Nombre 12,50
        patron_precio = re.compile(
            r'^[\s]*[\-\•\*]?\s*(.+?)\s+\$?\s*([0-9]+[.,]?[0-9]*)\s*$', 
            re.UNICODE | re.IGNORECASE
        )
        
        # Patrón: $12.50 Nombre
        patron_inverso = re.compile(
            r'^\$?\s*([0-9]+[.,]?[0-9]*)\s+(.+?)\s*$',
            re.UNICODE
        )
        
        visto = set()
        for linea in lineas:
            linea = linea.strip()
            if not linea or len(linea) < 4:
                continue
            
            nombre, precio = None, None
            
            # Intentar patrón normal
            match = patron_precio.match(linea)
            if match:
                nombre = match.group(1).strip().title()
                precio_str = match.group(2).replace(',', '.')
            else:
                # Intentar patrón inverso
                match = patron_inverso.match(linea)
                if match:
                    precio_str = match.group(1).replace(',', '.')
                    nombre = match.group(2).strip().title()
            
            if nombre and precio_str:
                try:
                    precio = float(precio_str)
                    # Filtrar valores razonables
                    if 0.10 <= precio <= 999.99:
                        # Limpiar nombre
                        nombre = re.sub(r'[^\w\sáéíóúñü]', '', nombre)
                        nombre = nombre.strip()
                        
                        if nombre and len(nombre) > 1 and nombre not in visto:
                            # Evitar duplicados
                            key = nombre.lower()
                            if key not in visto:
                                visto.add(key)
                                productos.append({
                                    "nombre": nombre,
                                    "precio": round(precio, 2)
                                })
                except ValueError:
                    continue
    
    except Exception as e:
        logger.error(f"Error en OCR: {e}")
        return []
    
    return productos

# ─── Handlers de Comandos ───────────────────────────────────────────────────

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /start"""
    user = update.effective_user
    
    # Registrar o actualizar usuario
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO usuarios (user_id, username, nombre)
        VALUES (?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            username = excluded.username,
            nombre = excluded.nombre
    """, (user.id, user.username or "", user.first_name or ""))
    conn.commit()
    conn.close()
    
    await update.message.reply_text(
        f"{animar('bienvenida')}\n"
        f"☕ ¡Bienvenido {user.first_name}!\n\n"
        f"📋 /menu - Ver menú\n"
        f"🛒 /pedido - Hacer pedido\n"
        f"📦 /mispedidos - Mis pedidos\n"
        f"👤 /perfil - Mi perfil\n"
        f"🔐 /admin - Panel admin",
        parse_mode=ParseMode.HTML
    )

async def registro(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /registro"""
    user = update.effective_user
    args = context.args
    
    if len(args) < 1:
        await update.message.reply_text(
            "Uso: /registro <nombre> [dirección] [teléfono]\n"
            "Ej: /registro Juan \"Calle 123\" 5551234"
        )
        return
    
    nombre = args[0]
    direccion = args[1] if len(args) > 1 else ""
    telefono = args[2] if len(args) > 2 else ""
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO usuarios (user_id, username, nombre, direccion, telefono)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            nombre = excluded.nombre,
            direccion = excluded.direccion,
            telefono = excluded.telefono
    """, (user.id, user.username or "", nombre, direccion, telefono))
    conn.commit()
    conn.close()
    
    await update.message.reply_text(
        f"✅ Registro completo:\n"
        f"👤 {nombre}\n"
        f"📍 {direccion}\n"
        f"📞 {telefono}"
    )

async def ver_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /menu"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Obtener productos disponibles
    c.execute("""
        SELECT p.nombre, p.precio, c.nombre 
        FROM productos p
        LEFT JOIN categorias c ON p.categoria_id = c.id
        WHERE p.disponible = 1
        ORDER BY c.nombre, p.nombre
    """)
    productos = c.fetchall()
    conn.close()
    
    if not productos:
        await update.message.reply_text(
            f"{animar('error')}\n📭 Menú vacío. Admin usa /agregar.",
            parse_mode=ParseMode.HTML
        )
        return
    
    # Agrupar por categoría
    categorias = {}
    for nombre, precio, cat in productos:
        cat = cat or "General"
        if cat not in categorias:
            categorias[cat] = []
        categorias[cat].append((nombre, precio))
    
    mensaje = f"{animar('cafe')}\n📋 **MENÚ**\n\n"
    
    for cat, items in categorias.items():
        mensaje += f"**{cat.upper()}**\n"
        for nombre, precio in items:
            mensaje += f"  • {nombre} — ${precio:.2f}\n"
        mensaje += "\n"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

async def hacer_pedido(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /pedido - Con botones inline"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT id, nombre, precio FROM productos WHERE disponible = 1 ORDER BY nombre")
    productos = c.fetchall()
    conn.close()
    
    if not productos:
        await update.message.reply_text(
            f"{animar('error')}\n📭 No hay productos disponibles.",
            parse_mode=ParseMode.HTML
        )
        return
    
    # Teclado inline
    keyboard = []
    row = []
    for i, (pid, nombre, precio) in enumerate(productos):
        btn_text = f"{nombre[:15]} ${precio:.2f}"
        row.append(InlineKeyboardButton(btn_text, callback_data=f"p_{pid}"))
        if (i + 1) % 2 == 0 or i == len(productos) - 1:
            keyboard.append(row)
            row = []
    
    keyboard.append([
        InlineKeyboardButton("✅ Finalizar", callback_data="fin"),
        InlineKeyboardButton("❌ Cancelar", callback_data="can")
    ])
    
    context.user_data['carrito'] = []
    
    await update.message.reply_text(
        f"{animar('pedido_recibido')}\n"
        "🛒 **NUEVO PEDIDO**\n"
        "Toca los productos para agregarlos:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.HTML
    )

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manejar botones inline"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "can":
        context.user_data['carrito'] = []
        await query.edit_message_text("❌ Pedido cancelado.")
        return
    
    if data == "fin":
        carrito = context.user_data.get('carrito', [])
        if not carrito:
            await query.edit_message_text("❌ Carrito vacío. Agrega productos.")
            return
        
        total = sum(item['precio'] for item in carrito)
        user_id = update.effective_user.id
        
        # Guardar pedido
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("""
            INSERT INTO pedidos (user_id, items, total, estado)
            VALUES (?, ?, ?, 'pendiente')
        """, (user_id, json.dumps(carrito, ensure_ascii=False), total))
        pedido_id = c.lastrowid
        conn.commit()
        conn.close()
        
        # Resumen
        resumen = f"{animar('listo')}\n"
        resumen += f"✅ **Pedido #{pedido_id}**\n\n"
        for item in carrito:
            resumen += f"• {item['nombre']} — ${item['precio']:.2f}\n"
        resumen += f"\n💰 **Total: ${total:.2f}**\n"
        resumen += "\n⏳ Espera confirmación del admin."
        
        await query.edit_message_text(resumen, parse_mode=ParseMode.MARKDOWN)
        
        # Notificar admins
        for admin_id in ADMIN_IDS:
            try:
                await context.bot.send_message(
                    admin_id,
                    f"📦 **Pedido #{pedido_id}**\n"
                    f"👤 {update.effective_user.first_name}\n"
                    f"💰 ${total:.2f}\n"
                    f"/confirmar {pedido_id}\n"
                    f"/listo {pedido_id}",
                    parse_mode=ParseMode.MARKDOWN
                )
            except:
                pass
        
        context.user_data['carrito'] = []
        return
    
    # Agregar producto al carrito
    if data.startswith("p_"):
        prod_id = int(data.split("_")[1])
        
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT nombre, precio FROM productos WHERE id = ?", (prod_id,))
        row = c.fetchone()
        conn.close()
        
        if row:
            nombre, precio = row
            if 'carrito' not in context.user_data:
                context.user_data['carrito'] = []
            
            context.user_data['carrito'].append({
                'id': prod_id, 'nombre': nombre, 'precio': precio
            })
            
            total = sum(i['precio'] for i in context.user_data['carrito'])
            
            await query.edit_message_text(
                f"✅ **{nombre}** agregado (${precio:.2f})\n"
                f"💰 Total: **${total:.2f}**\n\n"
                "Selecciona más o presiona Finalizar:",
                reply_markup=query.message.reply_markup,
                parse_mode=ParseMode.MARKDOWN
            )

async def mis_pedidos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /mispedidos"""
    user_id = update.effective_user.id
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT id, items, total, estado, creado_en 
        FROM pedidos WHERE user_id = ? 
        ORDER BY creado_en DESC LIMIT 5
    """, (user_id,))
    pedidos = c.fetchall()
    conn.close()
    
    if not pedidos:
        await update.message.reply_text("📭 Sin pedidos aún. Usa /pedido.")
        return
    
    emojis = {
        'pendiente': '⏳', 'confirmado': '✅',
        'preparando': '👨‍🍳', 'listo': '🎉', 'entregado': '📦'
    }
    
    mensaje = "📋 **MIS PEDIDOS**\n\n"
    for pid, items_json, total, estado, fecha in pedidos:
        items = json.loads(items_json)
        items_str = ", ".join([i['nombre'] for i in items])
        emoji = emojis.get(estado, '❓')
        mensaje += f"#{pid} {emoji} {estado.upper()}\n"
        mensaje += f"   {items_str}\n"
        mensaje += f"   💰 ${total:.2f}\n\n"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

async def perfil(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /perfil"""
    user_id = update.effective_user.id
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT nombre, rol, direccion, telefono FROM usuarios WHERE user_id = ?", (user_id,))
    row = c.fetchone()
    conn.close()
    
    if not row:
        await update.message.reply_text("Usa /registro para crear tu perfil.")
        return
    
    nombre, rol, direccion, telefono = row
    await update.message.reply_text(
        f"{animar('cafe')}\n"
        f"👤 **{nombre}**\n"
        f"🔐 Rol: {rol}\n"
        f"📍 {direccion or 'Sin dirección'}\n"
        f"📞 {telefono or 'Sin teléfono'}",
        parse_mode=ParseMode.HTML
    )

# ─── Comandos Admin ─────────────────────────────────────────────────────────

@solo_admin
async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /admin"""
    await update.message.reply_text(
        f"{animar('bienvenida')}\n"
        f"🔐 **PANEL ADMIN**\n\n"
        f"📸 Envía **foto del menú** → OCR automático\n"
        f"📝 /agregar <nom> <precio> [cat]\n"
        f"📋 /lista - Ver productos\n"
        f"❌ /eliminar <id> - Eliminar\n"
        f"🔄 /toggle <id> - Disponible/no\n"
        f"📦 /pedidos - Ver pendientes\n"
        f"✅ /confirmar <id>\n"
        f"👨‍🍳 /preparar <id>\n"
        f"🎉 /listo <id>\n"
        f"👥 /usuarios",
        parse_mode=ParseMode.MARKDOWN
    )

@solo_admin
async def agregar_producto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /agregar"""
    args = context.args
    if len(args) < 2:
        await update.message.reply_text(
            "Uso: /agregar \"Café Latte\" 3.50 [Bebidas]\n"
            "O envía una foto del menú para OCR automático."
        )
        return
    
    nombre = args[0]
    try:
        precio = float(args[1].replace(',', '.'))
    except ValueError:
        await update.message.reply_text("❌ Precio inválido")
        return
    
    cat = args[2] if len(args) > 2 else "General"
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("SELECT id FROM categorias WHERE nombre = ?", (cat,))
    row = c.fetchone()
    if row:
        cat_id = row[0]
    else:
        c.execute("INSERT INTO categorias (nombre) VALUES (?)", (cat,))
        cat_id = c.lastrowid
    
    c.execute("INSERT INTO productos (nombre, precio, categoria_id) VALUES (?, ?, ?)",
              (nombre, precio, cat_id))
    conn.commit()
    conn.close()
    
    await update.message.reply_text(f"✅ {nombre} — ${precio:.2f} [{cat}]")

@solo_admin
async def lista_productos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /lista"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT p.id, p.nombre, p.precio, c.nombre, p.disponible
        FROM productos p LEFT JOIN categorias c ON p.categoria_id = c.id
        ORDER BY p.nombre
    """)
    productos = c.fetchall()
    conn.close()
    
    if not productos:
        await update.message.reply_text("📭 No hay productos.")
        return
    
    mensaje = "📋 **PRODUCTOS**\n\n"
    for pid, nombre, precio, cat, disp in productos:
        icono = "✅" if disp else "❌"
        mensaje += f"{icono} `#{pid}` {nombre} — ${precio:.2f} [{cat}]\n"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

@solo_admin
async def eliminar_producto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /eliminar"""
    if not context.args:
        await update.message.reply_text("Uso: /eliminar <id>")
        return
    try:
        pid = int(context.args[0])
    except:
        await update.message.reply_text("❌ ID inválido")
        return
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("DELETE FROM productos WHERE id = ?", (pid,))
    ok = c.rowcount > 0
    conn.commit()
    conn.close()
    
    await update.message.reply_text(f"{'✅' if ok else '❌'} Producto #{pid}{' eliminado' if ok else ' no encontrado'}.")

@solo_admin
async def toggle_producto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /toggle - Cambiar disponibilidad"""
    if not context.args:
        await update.message.reply_text("Uso: /toggle <id>")
        return
    try:
        pid = int(context.args[0])
    except:
        await update.message.reply_text("❌ ID inválido")
        return
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT disponible FROM productos WHERE id = ?", (pid,))
    row = c.fetchone()
    if not row:
        await update.message.reply_text("❌ No encontrado")
        conn.close()
        return
    
    nuevo = 0 if row[0] else 1
    c.execute("UPDATE productos SET disponible = ? WHERE id = ?", (nuevo, pid))
    conn.commit()
    conn.close()
    
    estado = "disponible" if nuevo else "no disponible"
    await update.message.reply_text(f"✅ #{pid} ahora {estado}")

@solo_admin
async def ver_pedidos_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /pedidos (admin)"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT p.id, u.nombre, p.items, p.total, p.estado
        FROM pedidos p JOIN usuarios u ON p.user_id = u.user_id
        WHERE p.estado IN ('pendiente', 'confirmado', 'preparando')
        ORDER BY p.creado_en ASC LIMIT 5
    """)
    pedidos = c.fetchall()
    conn.close()
    
    if not pedidos:
        await update.message.reply_text("📭 Sin pedidos pendientes.")
        return
    
    emojis = {'pendiente': '⏳', 'confirmado': '✅', 'preparando': '👨‍🍳'}
    mensaje = "📦 **PEDIDOS**\n\n"
    for pid, nombre, items_json, total, estado in pedidos:
        items = json.loads(items_json)
        items_str = ", ".join([i['nombre'] for i in items])
        emoji = emojis.get(estado, '❓')
        mensaje += f"#{pid} {emoji} {estado.upper()} — {nombre}\n"
        mensaje += f"   {items_str}\n"
        mensaje += f"   💰 ${total:.2f}\n\n"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

@solo_admin
async def gestionar_estado(update: Update, context: ContextTypes.DEFAULT_TYPE, estado: str):
    """Cambiar estado de un pedido"""
    if not context.args:
        await update.message.reply_text(f"Uso: /{estado} <id>")
        return
    try:
        pid = int(context.args[0])
    except:
        await update.message.reply_text("❌ ID inválido")
        return
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT user_id, items, total FROM pedidos WHERE id = ?", (pid,))
    row = c.fetchone()
    if not row:
        await update.message.reply_text("❌ Pedido no encontrado")
        conn.close()
        return
    
    user_id, items_json, total = row
    c.execute("UPDATE pedidos SET estado = ? WHERE id = ?", (estado, pid))
    conn.commit()
    conn.close()
    
    msgs = {
        'confirmado': '✅ Confirmado',
        'preparando': '👨‍🍳 En preparación',
        'listo': '🎉 Listo para recoger'
    }
    
    await update.message.reply_text(f"{msgs.get(estado, estado)} #{pid}")
    
    # Notificar cliente
    try:
        items = json.loads(items_json)
        items_str = "\n".join([f"• {i['nombre']}" for i in items])
        await context.bot.send_message(
            user_id,
            f"📦 **Pedido #{pid}**\n"
            f"Estado: **{estado.upper()}**\n\n"
            f"{items_str}\n💰 Total: ${total:.2f}"
        )
    except:
        pass

@solo_admin
async def confirmar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await gestionar_estado(update, context, 'confirmado')

@solo_admin
async def preparar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await gestionar_estado(update, context, 'preparando')

@solo_admin
async def listo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await gestionar_estado(update, context, 'listo')

@solo_admin
async def listar_usuarios(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /usuarios"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT user_id, nombre, rol FROM usuarios ORDER BY nombre")
    usuarios = c.fetchall()
    conn.close()
    
    if not usuarios:
        await update.message.reply_text("Sin usuarios.")
        return
    
    mensaje = "👥 **USUARIOS**\n\n"
    for uid, nombre, rol in usuarios:
        mensaje += f"`{uid}` **{nombre}** ({rol})\n"
    
    await update.message.reply_text(mensaje, parse_mode=ParseMode.MARKDOWN)

# ─── Handler de Fotos (OCR) ─────────────────────────────────────────────────

async def foto_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Procesa fotos del menú enviadas por admins"""
    user_id = update.effective_user.id
    
    # Verificar admin
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT rol FROM usuarios WHERE user_id = ?", (user_id,))
    row = c.fetchone()
    conn.close()
    
    if not row or row[0] not in ('admin', 'superadmin'):
        await update.message.reply_text(
            f"{animar('error')}\n⛔ Solo admins pueden subir menús.",
            parse_mode=ParseMode.HTML
        )
        return
    
    if not OCR_DISPONIBLE:
        await update.message.reply_text(
            "⚠️ OCR no disponible.\n"
            "Instala: `pip install easyocr` y reinicia.",
            parse_mode=ParseMode.MARKDOWN
        )
        return
    
    # Descargar foto
    photo_file = await update.message.photo[-1].get_file()
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    photo_path = str(FOTOS_DIR / f"menu_{user_id}_{timestamp}.jpg")
    await photo_file.download_to_drive(photo_path)
    
    msg = await update.message.reply_text(
        f"{animar('cargando')}\n🔍 Procesando menú con {MODO_OCR}...",
        parse_mode=ParseMode.HTML
    )
    
    # Extraer productos
    productos = procesar_imagen_menu(photo_path)
    
    # Limpiar archivo
    try:
        os.remove(photo_path)
    except:
        pass
    
    if not productos:
        await msg.edit_text(
            f"{animar('error')}\n"
            "❌ No se pudieron extraer productos.\n\n"
            "Tips:\n"
            "• Foto clara, buena iluminación\n"
            "• Formato: \"Nombre $12.50\"\n"
            "• También usa /agregar manual",
            parse_mode=ParseMode.HTML
        )
        return
    
    # Guardar en BD
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    nuevos = 0
    for prod in productos:
        c.execute("SELECT id FROM productos WHERE nombre = ?", (prod['nombre'],))
        if not c.fetchone():
            c.execute("INSERT INTO productos (nombre, precio) VALUES (?, ?)",
                      (prod['nombre'], prod['precio']))
            nuevos += 1
    
    conn.commit()
    conn.close()
    
    resumen = f"✅ **Menú procesado**\n\n"
    resumen += f"📸 Detectados: {len(productos)}\n"
    resumen += f"➕ Nuevos: {nuevos}\n"
    resumen += f"🔁 Repetidos: {len(productos)-nuevos}\n\n"
    
    if productos:
        resumen += "**Productos:**\n"
        for i, prod in enumerate(productos[:10], 1):
            resumen += f"{i}. {prod['nombre']} — ${prod['precio']:.2f}\n"
        if len(productos) > 10:
            resumen += f"... y {len(productos)-10} más\n"
    
    resumen += "\n📋 /menu para ver el menú"
    
    await msg.edit_text(resumen, parse_mode=ParseMode.MARKDOWN)

# ─── Script de instalación para Termux ─────────────────────────────────────

def instalar_termux():
    """Instala todo lo necesario en Termux automáticamente"""
    print("[*] Instalando CaféBot para Termux...")
    print("[*] Autorización verificada - Pentest autorizado")
    
    # Paquetes Termux
    paquetes = ["python", "clang", "libxml2", "libxslt"]
    
    print("[*] Actualizando paquetes...")
    subprocess.run(["pkg", "update", "-y"], capture_output=True)
    
    for pkg in paquetes:
        print(f"[*] Instalando {pkg}...")
        subprocess.run(["pkg", "install", "-y", pkg], capture_output=True)
    
    # Dependencias Python (sin opencv para ahorrar espacio)
    print("[*] Instalando dependencias Python...")
    subprocess.run([
        sys.executable, "-m", "pip", "install",
        "python-telegram-bot", "easyocr"
    ], check=True)
    
    print("[✓] Instalación completada!")
    print(f"\n[*] Para ejecutar:")
    print(f"    cd {Path.cwd()}")
    print(f"    export BOT_TOKEN='tu_token_aqui'")
    print(f"    export ADMIN_IDS='123456789'")
    print(f"    python3 {Path(__file__).name}")
    print(f"\n[*] O crea un script de inicio:")
    print(f"""    cat > run_bot.sh << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
export BOT_TOKEN='tu_token'
export ADMIN_IDS='123456789'
cd {Path.cwd()}
python3 {Path(__file__).name}
EOF
    chmod +x run_bot.sh""")
    sys.exit(0)

# ─── Main ────────────────────────────────────────────────────────────────────

def main():
    """Punto de entrada principal"""
    
    # Auto-instalación para Termux
    if "--install" in sys.argv:
        instalar_termux()
        return
    
    if len(sys.argv) > 1 and sys.argv[1] == "--install":
        instalar_termux()
        return
    
    # Inicializar BD
    init_db()
    
    # Verificar token
    if TOKEN == "AQUI_TU_TOKEN":
        print("[!] Configura tu token:")
        print("    export BOT_TOKEN='tu_token_de_botfather'")
        print("  O edita la variable TOKEN en el código.")
        print("  O ejecuta: python3 bot.py --install")
        sys.exit(1)
    
    if not ADMIN_IDS or ADMIN_IDS == [123456789]:
        print("[!] Configura ADMIN_IDS:")
        print("    export ADMIN_IDS='tu_id_telegram'")
        print("  O edita la variable en el código.")
        sys.exit(1)
    
    # Crear aplicación
    app = Application.builder().token(TOKEN).build()
    
    # Handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("registro", registro))
    app.add_handler(CommandHandler("menu", ver_menu))
    app.add_handler(CommandHandler("pedido", hacer_pedido))
    app.add_handler(CommandHandler("mispedidos", mis_pedidos))
    app.add_handler(CommandHandler("perfil", perfil))
    
    # Admin
    app.add_handler(CommandHandler("admin", admin_panel))
    app.add_handler(CommandHandler("agregar", agregar_producto))
    app.add_handler(CommandHandler("lista", lista_productos))
    app.add_handler(CommandHandler("eliminar", eliminar_producto))
    app.add_handler(CommandHandler("toggle", toggle_producto))
    app.add_handler(CommandHandler("pedidos", ver_pedidos_admin))
    app.add_handler(CommandHandler("confirmar", confirmar))
    app.add_handler(CommandHandler("preparar", preparar))
    app.add_handler(CommandHandler("listo", listo))
    app.add_handler(CommandHandler("usuarios", listar_usuarios))
    
    # Fotos y botones
    app.add_handler(MessageHandler(filters.PHOTO, foto_handler))
    app.add_handler(CallbackQueryHandler(button_handler))
    
    # Banner de inicio
    print("""
╔══════════════════════════╗
║   ☕ CAFETERÍA BOT v2   ║
║   Optimizado para Termux ║
╠══════════════════════════╣
""")
    print(f"[✓] Base de datos: {DB_PATH}")
    print(f"[✓] OCR: {MODO_OCR}")
    print(f"[✓] Admins: {len(ADMIN_IDS)}")
    print(f"[✓] Fotos: {FOTOS_DIR}")
    print(f"[*] Bot iniciado. Ctrl+C para detener.\n")
    
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
